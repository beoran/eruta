/* 
 * Copyright (c) 2011-2012  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#ifndef __DAPARTEST_H__
#define __DAPARTEST_H__

#include "dapar.h"

typedef struct {
	const char *input;
	const char *correctresult;
} testcase_t;

extern int dapar_test_main(const dapar_rule_t *grammar,
	const testcase_t *testcase, int argc, char *argv[]);

#endif
