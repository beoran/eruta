/* 
 * Copyright (c) 2011-2012  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#if defined(_WIN32)
#define snprintf _snprintf
#elif defined(__linux__)
#define _BSD_SOURCE  /* for snprintf */
#endif
#include <stdio.h>
#include <string.h>     /* strcmp() */
#include <stdlib.h>	/* atoi() */
#include "dapar.h"
#include "dapartest.h"

typedef enum {
	UNKNOWN,
	CMDLINE,
	READFILE,
	STDIN,
	STDIN_SHELL,
	TESTCASES
} testmode_t;

static int ntestcases = 0;
static testmode_t testmode = UNKNOWN;
static int testcases_runs = 1;
static int single_testcase = 0;
static int testcase_as_input = 0;
static const char *inputfile = NULL;
static dapar_bool_t print_all_matches = 0;
static dapar_bool_t quiet = 0;
static dapar_bool_t exercise = 0;
static dapar_bool_t format_dump = 1;

static int snprint_indent(char *buf, int buflen, int depth)
{
	int i, len = 0;
	for (i = 0; i < depth; i++) {
		if (len >= buflen) break;
		len += snprintf(buf+len, buflen-len, "    ");
	}
	return len;
}

static int snprint_quoted(char *buf, int buflen, const char *unquoted)
{
	const char *src = unquoted;
	char tmp[2048], *dest = tmp, *const destmax = tmp + sizeof(tmp);
	while (*src && dest < destmax-2) {
		char c = *src;
		if (c == '\\') {
			dest[0] = '\\';
			dest[1] = '\\';
			dest += 2;
		} else if (c == '\r') {
			dest[0] = '\\';
			dest[1] = 'r';
			dest += 2;
		} else if (c == '\n') {
			dest[0] = '\\';
			dest[1] = 'n';
			dest += 2;
		} else if (c == '\"') {
			dest[0] = '\\';
			dest[1] = '\"';
			dest += 2;
		} else {
			dest[0] = c;
			dest++;
		}
		src++;
	}
	*dest = '\0';
	return snprintf(buf, buflen, "%s", tmp);
}

static int dump_node(const dapar_match_t *top, int depth,
		char *buf, int buflen)
{
	int len = 0, nextdepth = (depth < 0) ? depth : depth + 1;
#define APPEND(s) \
	if (len < buflen) { \
		len += snprintf(buf+len, buflen-len, "%s", s); \
	}
#define INDENT(n) \
	if (len < buflen && n > 0) { \
		len += snprint_indent(buf+len, buflen-len, n); \
	}
#define NEWLINE \
	if (depth >= 0) { \
		APPEND("\n"); \
	}
	INDENT(depth);
	APPEND(top->rule->name);
	if (top->text != NULL) {
		APPEND("'");
		if (depth >= 0) {
			if (len < buflen) {
				len += snprint_quoted(buf+len, buflen-len,
						top->text);
			}
		} else {
			APPEND(top->text);
		}
		APPEND("'");
	}
	if (top->firstchild != NULL) {
		APPEND("{");
		NEWLINE;
		if (len < buflen)
			len += dump_node(top->firstchild, nextdepth,
					buf+len, buflen-len);
		NEWLINE;
		INDENT(depth);
		APPEND("}");
	}
	if (top->nextsibling != NULL) {
		APPEND(",");
		NEWLINE;
		if (len < buflen)
			len += dump_node(top->nextsibling, depth,
					buf+len, buflen-len);
	}
	if (len >= buflen) {
		len = buflen;
		buf[len-1] = '\0';
	}
	return len;
}

static void dump_tree(const dapar_tree_t *tree, char *buf, int buflen,
		dapar_bool_t formatted)
{
	dump_node(tree->root, formatted ? 0 : -1, buf, buflen);
}

static void print_tree(const dapar_match_t *top, int indent)
{
	int i;
	for (i=0; i < indent; i++) {
		printf("    ");
	}
	printf("%s @ %d len %d",
		top->rule->name, top->origin.offset, top->length);
	if (top->text != NULL) {
		printf("  \"%s\"\n", top->text);
	} else {
		printf("\n");
	}
	if (top->firstchild != NULL) {
		print_tree(top->firstchild, indent+1);
	}
	if (top->nextsibling != NULL) {
		print_tree(top->nextsibling, indent);
	}
}

static dapar_bool_t verify_tree(const dapar_tree_t *tree)
{
	int i;
	dapar_match_t *min, *max;
	const char *errtext[64];
	int errindex[64];
	int errs = 0;
#define VERIFY(truth) \
	if (!(truth)) { \
		errtext[errs] = #truth; \
		errindex[errs] = i; \
		errs++; \
	}
	min = tree->elem;
	max = tree->elem + tree->elems;
	for (i = 0; i < tree->elems; i++) {
		dapar_match_t *x = tree->elem + i;
		if (!x->used) continue;
		if (x->parent == NULL) {
			VERIFY(x == tree->root || x->prevsibling != NULL);
		} else {
			dapar_match_t *p = x->parent;
			dapar_match_t *c = p->firstchild;
			VERIFY(c != NULL);
			while (c != NULL) {
				if (c == x) break;
				c = c->nextsibling;
			}
			VERIFY(c == x);
			VERIFY(p >= min && p < max);
			VERIFY(x->origin.offset >= p->origin.offset);
			VERIFY(x->origin.offset + x->length <=
			       p->origin.offset + p->length);
		}
		if (x->nextsibling == NULL) {
			if (x->parent != NULL) {
				VERIFY(x->parent->lastchild == x);
			}
		} else {
			VERIFY(x->nextsibling >= min && x->nextsibling < max);
			VERIFY(x->nextsibling->prevsibling == x);
		}
		if (x->prevsibling == NULL) {
			if (x->parent != NULL) {
				VERIFY(x->parent->firstchild == x);
			}
		} else {
			VERIFY(x->prevsibling >= min && x->prevsibling < max);
			VERIFY(x->prevsibling->nextsibling == x);
		}
		if (x->firstchild != NULL) {
			dapar_match_t *y;
			VERIFY(x->firstchild >= min && x->firstchild < max);
			VERIFY(x->firstchild->parent == x);
			VERIFY(x->firstchild->prevsibling == NULL);
			y = x->firstchild;
			while (y != NULL) {
				VERIFY(y->parent == x);
				y = y->nextsibling;
			}
		}
		if (x->lastchild != NULL) {
			VERIFY(x->lastchild >= min && x->lastchild < max);
			VERIFY(x->lastchild->parent == x);
			VERIFY(x->lastchild->nextsibling == NULL);
		}
		if (x->rule->type == DAPAR_RULE_TOKEN) {
			VERIFY(x->text != NULL);
		} else {
			VERIFY(x->text == NULL);
		}
		if (x->text != NULL) {
			VERIFY(x->rule->type == DAPAR_RULE_TOKEN);
		} else {
			VERIFY(x->rule->type != DAPAR_RULE_TOKEN);
		}
	}
	if (errs) {
		int e;
		printf("Errors found in tree structure:\n");
		for (e=0; e < errs; e++) {
			printf("\telem[%d] FAILED: %s\n",
				errindex[e], errtext[e]);
		}
	}
	return !errs;
}

static int match_idx(dapar_match_t *m, const dapar_tree_t *t)
{
	return (m == NULL) ? -1 : (int)(m - t->elem);
}

static void print_matches(const dapar_tree_t *t)
{
	int i = 0;
	printf("[id] name       off len par ch1 chN nxt pre ref use dep tok\n");
	for (i=0; i < t->elems; i++) {
		dapar_match_t *match = t->elem + i;
		if (match->rule == NULL ||
		    (!match->used && !print_all_matches)) continue;
		printf("[%2d] %-9s %s %3d %3d %3d %3d %3d %3d %3d %3d %3d "
			"%3d ",
			i,
			match->rule->name,
			(strlen(match->rule->name) > 9) ?
				"\n               " : "",
			match->origin.offset,
			match->length,
			match_idx(match->parent, t),
			match_idx(match->firstchild, t),
			match_idx(match->lastchild, t),
			match_idx(match->nextsibling, t),
			match->prevmatch,
			match->refcount,
			match->used,
			match->depth
			);
		if (!match->used) {
			printf("<superseded>\n");
		} else if (match->text != NULL) {
			printf("\"%s\"\n", match->text);
		} else {
			printf("\n");
		}
	}
}

static int run_testcases(dapar_stream_t *m, const testcase_t *testcase)
{
	char buf[1024];
	int total = 0, passes = 0;
	const testcase_t *tc = testcase;
	if (single_testcase)
		tc += single_testcase - 1;
	while (tc->input != NULL) {
		const dapar_tree_t *t;
		int v = 1, pass;
		dapar_err_t err = dapar_stream_reset(m);
		total++;
		buf[0] = '\0';
		if (!quiet)
			printf("Testcase %d: '%s'\n",
				(int)(tc - testcase)+1, tc->input);
		v = 1;
		dapar_stream_configure(m, DAPAR_KEEPANON, 0);
		if (!err)
			err = dapar_stream_input_utf8(m, tc->input, -1);
		if (!err) {
			err = dapar_stream_end(m, &t);
			if (!err) {
				dump_tree(t, buf, sizeof(buf)-1, 0);
				if (!verify_tree(t)) v = 0;
				if (exercise) {
					dapar_tree_t mytree;
					dapar_stream_copytree(m, &mytree);
					dapar_tree_free(&mytree);
				}
			}
		}
		if (!err) {
			/* Now check for ambiguities hiding in anon rules */
			t = NULL;  /* t has been invalidated anyway */
			err = dapar_stream_reset(m);
			if (!err) {
				dapar_stream_configure(m, DAPAR_KEEPANON, 1);
				err = dapar_stream_input_utf8(m,
						tc->input, -1);
				if (!err)
					err = dapar_stream_end(m, NULL);
			}
		}
		if (err) {
			const dapar_errorinfo_t *error =
				dapar_stream_errorinfo(m);
			snprintf(buf, sizeof(buf),
				"Error at line %d col %d: %s%s",
				error->pos.line, error->pos.column,
				dapar_err_string(err),
				dapar_stream_configured(m, DAPAR_KEEPANON) ?
					" in anonymous match" : ""
				);
		}
		if (!quiet) {
			printf("Verify: %s\n", v?"VERIFIED":"ERROR^^");
			printf("Output: ");
		}
		pass = 0;
		if (!strcmp(tc->correctresult, buf)) {
			if (!quiet)
				printf("EXPECTED\n");
			pass = v;
		} else if (!quiet) {
			printf("UNEXPECTED\n"
				"\tExpected: %s\n"
				"\tGot     : %s\n",
				tc->correctresult,
				buf);
		}
		if (!quiet)
			printf("Result: %s\n", pass?"PASS":"FAIL");
		passes += pass;
		tc++;
		if (single_testcase) break;
	}
	if (!quiet) {
		printf("----------\n"
			"Passed %d of %d test cases (%d%%)\n",
			passes, total, passes * 100 / total);
	}
	return (total - passes);
}

static void print_single_result(dapar_stream_t *m, int promptlen)
{
	char buf[1024];
	dapar_err_t err;
	const dapar_tree_t *t;
	err = dapar_stream_end(m, &t);
	if (!err) {
		if (!quiet) {
			dump_tree(t, buf, sizeof(buf)-1, format_dump);
			printf("\n--- Test result ---\n"
				"%s\n",
				buf);
			printf("\n--- Raw tree elements ---\n");
			print_matches(t);
		}
		verify_tree(t);
		if (!quiet) {
			printf("\n--- Tree structure ---\n");
			print_tree(t->root, 0);
		}
		if (exercise) {
			dapar_tree_t mytree;
			dapar_stream_copytree(m, &mytree);
			dapar_tree_free(&mytree);
		}
	}

	if (err) {
		const dapar_errorinfo_t *error = dapar_stream_errorinfo(m);
		if (promptlen > 0)
			printf("%*c\n", promptlen + error->pos.column, '^');
		printf("Error at line %d col %d: %s%s\n",
			error->pos.line, error->pos.column,
			dapar_err_string(error->err),
			dapar_stream_configured(m, DAPAR_KEEPANON) ?
				" in anonymous match" : "");
	}
}

static void show_help(char *argv[])
{
	printf("DaparTest (library version %d.%d.%d)\n",
		DAPAR_VERSION_MAJOR(dapar_version),
		DAPAR_VERSION_MINOR(dapar_version),
		DAPAR_VERSION_SERVICE(dapar_version));
	printf("Usage: %s [OPTIONS] [input-text]\n"
		"\n"
		"  -a     Show anonymous matches (normally hidden).\n"
		"  -c     Take input-text from standard input (same as -f-).\n"
		"  -dN    Disambiguate an ambiguous grammar by showing "
				"the Nth solution (N > 0).\n"
		"  -e     Exercise unused API functions.\n"
		"  -fFILE Take input-text from FILE (or - for stdin).\n"
		"  -h     Show this help information.\n"
		"  -iN    Take input-text from test case N (1..%d).\n"
		, argv[0], ntestcases);
	printf(
		"  -m     Print all intermediate matches in the table, not "
				"just the final ones.\n"
		"  -q     Quiet mode; only print errors.\n"
		"  -rN    Repeat testcase runs N times.\n"
		"  -s     Enter shell mode (only works with single-expression "
				"grammars).\n"
		"  -t[N]  Run built-in testcases, or just testcase N "
			"(1..%d).\n"
		"  -u     Show unformatted test result.\n"
		"  --     Ignore all parameters that follow.\n"
		"\n"
		"Defaults:  -t -r1\n"
		, ntestcases);
}

static int count_testcases(const testcase_t *testcase)
{
	const testcase_t *tc = testcase;
	int count = 0;
	while (tc != NULL && tc->input != NULL) {
		count++;
		tc++;
	}
	return count;
}

static int load_options(int argc, char *argv[], dapar_stream_t *m)
{
	int i;
	testmode = UNKNOWN;
	for (i = 1; i < argc; i++) {
		const char *arg = argv[i];
		if (arg[0] != '-') {
			if (testmode == UNKNOWN) {
				testmode = CMDLINE;
				break;
			} else {
				printf("Unexpected parameter: %s\n", arg);
				show_help(argv);
				return -1;
			}
		}
		switch (arg[1]) {
		case '-':
			if (arg[2]) {
				show_help(argv);
				return -1;
			} else {
				testmode = CMDLINE;
				return i;
			}
		case 'a':
			dapar_stream_configure(m, DAPAR_KEEPANON, 1);
			break;
		case 'c':
			testmode = STDIN;
			break;
		case 'd':
			dapar_stream_configure(m, DAPAR_DISAMBIGUATE,
				atoi(arg+2));
			break;
		case 'e':
			exercise = 1;
			break;
		case 'f':
			testmode = READFILE;
			if (arg[2])
				inputfile = arg + 2;
			else if (i + 1 < argc)
				inputfile = argv[++i];
			else {
				printf("Missing file name for -%c\n", arg[1]);
				return -1;
			}
			break;
		case 'h':
			show_help(argv);
			return -1;
		case 'i':
			testmode = CMDLINE;
			testcase_as_input = 0;
			if (arg[2])
				testcase_as_input = atoi(arg+2);
			break;
		case 'm':
			print_all_matches = 1;
			break;
		case 'q':
			quiet = 1;
			break;
		case 'r':
			testmode = TESTCASES;
			if (arg[2])
				testcases_runs = atoi(arg+2);
			break;
		case 's':
			testmode = STDIN_SHELL;
			break;
		case 't':
			testmode = TESTCASES;
			single_testcase = 0;
			if (arg[2])
				single_testcase = atoi(arg+2);
			break;
		case 'u':
			format_dump = 0;
			break;
		default:
			printf("Invalid option: %s\n", arg);
			show_help(argv);
			return -1;
		}
	}
	if (testcase_as_input || single_testcase) {
		if (testcase_as_input < 0 || testcase_as_input > ntestcases) {
			printf("Invalid testcase number: -i%d\n",
				testcase_as_input);
			return -1;
		}
		if (single_testcase < 0 || single_testcase > ntestcases) {
			printf("Invalid testcase number: -t%d\n",
				single_testcase);
			return -1;
		}
	}
	return i - 1;
}

int dapar_test_main(const dapar_rule_t *grammar, const testcase_t *testcase,
		int argc, char *argv[])
{
	dapar_stream_t m;
	int nopts, ret = 0;
	dapar_err_t err = DAPAR_SUCCESS;

	dapar_stream_init(&m, grammar);
	ntestcases = count_testcases(testcase);
	nopts = load_options(argc, argv, &m);
	if (nopts < 0)
		return -nopts;

	if (testmode == UNKNOWN)
		testmode = TESTCASES;

	if (testmode == TESTCASES) {
		if (testcase != NULL && testcase->input != NULL) {
			int run;
			for (run = 0; run < testcases_runs; run++)
				ret = run_testcases(&m, testcase);
		} else {
			printf("No testcases defined.\n");
		}
	} else if (testmode == CMDLINE) {
		const char *input;
		if (testcase_as_input) {
			input = testcase[testcase_as_input-1].input;
		} else {
			int inputarg = nopts + 1;
			input = argv[inputarg];
			if (inputarg >= argc)
				return 1;
		}
		printf("--- Input ---\n%s\n", input);
		err = dapar_stream_input_utf8(&m, input, -1);
		print_single_result(&m, 0);
	} else if (testmode == STDIN || testmode == READFILE) {
		char buf[128];
		const char *path = inputfile;
		FILE *file = (path == NULL || (path[0] == '-' && !path[1])) ?
			stdin : fopen(path, "r");
		if (file == NULL) {
			printf("Failed to open file: %s\n", path);
			return DAPAR_ERR_ARG;
		}
		while (!err) {
			int got = (int)fread(buf, 1, sizeof(buf), file);
			if (!got) break;
			err = dapar_stream_input_utf8(&m, buf, got);
		}
		print_single_result(&m, 0);
		if (file != NULL && path != NULL) {
			fclose(file);
		}
	} else if (testmode == STDIN_SHELL) {
		char buf[128];
		int promptlen;
		while (!err) {
			promptlen = printf("%s> ", argv[0]);
			while (fgets(buf, sizeof(buf), stdin) != NULL) {
				err = dapar_stream_input_utf8(&m, buf, -1);
				if (err || dapar_stream_matched(&m)) {
					break;
				}
				promptlen = printf("> ");
			}
			if (feof(stdin)) {
				printf("\n");
				break;
			}
			print_single_result(&m, promptlen);
			err = dapar_stream_reset(&m);
		}
	}
	if (!ret)
		ret = (int)err;

	dapar_stream_free(&m);

	return ret;
}
