/* 
 * Copyright (c) 2011-2012  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */
#ifndef __DAPAR_H__
#define __DAPAR_H__

#include <stddef.h> /* for NULL */

#define DAPAR_VERSION(_a, _b, _c) ((_a) << 16 | (_b) << 8 | (_c))
#define DAPAR_HEADER_VERSION      DAPAR_VERSION(1, 0, 0)
#define DAPAR_VERSION_MAJOR(_v)   ((_v) >> 16)
#define DAPAR_VERSION_MINOR(_v)   (((_v) >> 8) & 0xFF)
#define DAPAR_VERSION_SERVICE(_v) ((_v) & 0xFF)

typedef enum {
	DAPAR_RULE_RULE,
	DAPAR_RULE_ANONYMOUS,
	DAPAR_RULE_TOKEN
} dapar_rule_type_t;

/* A rule can be a dapar_rule_t or a string. It's only a dapar_rule_t if the
   first two characters are _DAPAR_RULE_HEAD */
typedef struct dapar_rule {
	char header[4];
	const char *name;
	int tag; /* User-defined tag. Do whatever you want with this */
	dapar_rule_type_t type;
	const struct dapar_rule **def;
} dapar_rule_t;

#define DAPAR_OR                NULL
#define _DAPAR_EXCEPT           "\0!"
#define _DAPAR_RULE_HEAD        "\0="

#define DAPAR_BEGIN(_id, _tag, _type) const void * _id##_def[]; \
                                const dapar_rule_t _id[1] = \
                                        {{_DAPAR_RULE_HEAD, #_id, _tag, \
                                        DAPAR_RULE_##_type, \
                                        (const dapar_rule_t **)_id##_def}}; \
                                const void * _id##_def[] = {
#define DAPAR_END               DAPAR_OR, DAPAR_OR};
#define DAPAR_EXTERN(_id)       extern const dapar_rule_t _id[1];
#define DAPAR_RULE_STR(_id)     ((const char**)(_id->def))

#define DAPAR_RULE(_id)         DAPAR_BEGIN(_id, 0, RULE)
#define DAPAR_ANON(_id)         DAPAR_BEGIN(_id, 0, ANONYMOUS)
#define DAPAR_TOKN(_id)         DAPAR_BEGIN(_id, 0, TOKEN)

/*
 * DAPAR_CHAR specifies a character set and matches a single character.
 *
 * For example:
 * DAPAR_RULE(digit)       DAPAR_CHAR("0-9"), DAPAR_END
 * DAPAR_RULE(hexdigit)    DAPAR_CHAR("0-9a-fA-F"), DAPAR_END
 * DAPAR_RULE(variable)    DAPAR_CHAR("a-zA-Z_"), DAPAR_OPTIONAL_NEXT(2),
 *                             DAPAR_CHAR("0-9a-zA-Z_"), DAPAR_REPEAT_PREV(1),
 *                         DAPAR_END
 * DAPAR_RULE(vowel)       DAPAR_CHAR("aeiouAEIOU"), DAPAR_END
 * DAPAR_RULE(stringchar)  DAPAR_CHAR("^'\""), DAPAR_END
 *
 * And even Unicode characters:
 * DAPAR_RULE(ellipsis)    DAPAR_CHAR("#x2026"), DAPAR_END
 * DAPAR_RULE(greekchar)   DAPAR_CHAR("#x370-#x3FF"), DAPAR_END
 */
#define DAPAR_CHAR(_set) "\0[" _set

/*
 * DAPAR_SPACE is an internally optimized version of:
 *
 * DAPAR_RULE(DAPAR_SPACE) DAPAR_OR,
 *                         DAPAR_CHAR(" \t\r\n"), DAPAR_REPEAT_PREV(1),
 *                         DAPAR_END
 *
 * which means zero or more whitespace characters. Using DAPAR_SPACE instead of
 * writing your own rule seems to improve performance (code and data) of the
 * test suite by about 10%.
 */
#define DAPAR_SPACE "\0_"

/*
 * DAPAR_ANYCHAR matches any character.
 * There are not many situations in which this is useful, but one example is a
 * quoted character inside a string:  "string \"contains\" quotes"
 * 
 * DAPAR_ANON(quotedch)    "\\", DAPAR_ANYCHAR, DAPAR_OR,
 *                         DAPAR_CHAR("^\\\""), DAPAR_END
 * DAPAR_RULE(string)      "\"", quotedch, DAPAR_REPEAT_PREV(1), "\"",
 *                         DAPAR_END
 */
#define DAPAR_ANYCHAR "\0."

/*
 * DAPAR_OPTIONAL_NEXT and DAPAR_REPEAT_PREV are short-cuts that allow you
 * to avoid writing recursive rules, and so give better performance than
 * writing the same rule in recursive form.
 *
 * However, if your rule can match the empty string and looks like:
 *    DAPAR_RULE(x) DAPAR_OPTIONAL_NEXT(2), y, z, DAPAR_END
 * then you'll get better performance by rewriting it as:
 *    DAPAR_RULE(x) DAPAR_OR, y, z, DAPAR_END
 */
#define DAPAR_OPTIONAL_NEXT(_n) "\0?" #_n
#define DAPAR_REPEAT_PREV(_n)   "\0+" #_n

#define DAPAR_EXCEPT  _DAPAR_EXCEPT, DAPAR_OR

typedef enum {
	DAPAR_SUCCESS = 0,
	DAPAR_ERR_MEM = 1,
	DAPAR_ERR_CHAR = 2,
	DAPAR_ERR_MULTIBYTE = 3,
	DAPAR_ERR_EOS = 4,
	DAPAR_ERR_BADRULE = 5,
	DAPAR_ERR_ARG = 6,
	DAPAR_ERR_AMBIGUOUS = 7,
	_DAPAR_ERRS
} dapar_err_t;

#ifndef DAPAR_U32_T
#define DAPAR_U32_T   unsigned int
#endif
#ifndef DAPAR_U16_T
#define DAPAR_U16_T   unsigned short
#endif
typedef DAPAR_U32_T   dapar_u32_t;
typedef DAPAR_U16_T   dapar_u16_t;
typedef dapar_u32_t   dapar_ucs4_t;
typedef dapar_u16_t   dapar_ucs2_t;
typedef dapar_ucs4_t  dapar_unicode_t;
typedef unsigned char dapar_byte_t;
typedef char          dapar_ascii_t;
typedef int           dapar_bool_t;

typedef struct {
	int offset; /* offset in characters, not necessarily bytes */
	int line;
	int column;
} dapar_pos_t;

typedef struct {
	const dapar_rule_t **rule;
	const dapar_rule_t *rulehead;
	int subrule;
	int textorigin;
	int prevmatch;
	int firstcaller;
	int nextcaller;
	int reloc;
	dapar_bool_t matchedempty;
	dapar_pos_t origin;
	int depth;
	int exceptid;
	int exceptoffset;
} dapar_state_t;

typedef struct dapar_match {
	const dapar_rule_t *rule;
	dapar_pos_t origin;
	int length;     /* match length in characters, otherwise -1 */
	char *text;     /* Text matching a DAPAR_TOKN, otherwise NULL */
	int textsize;   /* text string size in bytes, otherwise -1 */
	struct dapar_match *parent;
	struct dapar_match *firstchild;
	struct dapar_match *lastchild;
	struct dapar_match *nextsibling;
	struct dapar_match *prevsibling;
	int depth;
	void *user;     /* User-defined data. Put whatever you want here. */
	int used;
	int refcount;
	int prevmatch;
	int nextsame;
} dapar_match_t;

typedef struct {
	dapar_match_t *root;
	dapar_match_t *elem;
	int elems;
	char *textbuf;
} dapar_tree_t;

typedef struct {
	dapar_state_t *state;
	int size;
	int max;
} dapar_queue_t;

#define DAPAR_AMBIGUITYTOLERANCE_DEFAULT 200000
#define DAPAR_KEEPANON_DEFAULT 0
#define DAPAR_DISAMBIGUATE_DEFAULT 0
#define DAPAR_MAXSTATES_DEFAULT 10000

typedef enum {
	DAPAR_AMBIGUITYTOLERANCE = 0,
	DAPAR_KEEPANON = 1,
	DAPAR_DISAMBIGUATE = 2,
	DAPAR_MAXSTATES = 3,
	_DAPAR_SETTINGS = 4
} dapar_setting_t;

typedef struct {
	dapar_err_t err;
	dapar_pos_t pos;
} dapar_errorinfo_t;

typedef struct {
	const dapar_rule_t *grammar;
	dapar_queue_t queue[2], *current, *next;
	dapar_pos_t pos;
	dapar_match_t *match;
	dapar_errorinfo_t error;
	int maxmatches;
	int nmatches;
	int firstfreematch;
	int lastgrammarmatch;
	dapar_bool_t couldgrammarmatch;
	int startold, endold;
	char *textbuf;
	int textmax;
	int textused;
	int lastsure;
	int intoken;
	int setting[_DAPAR_SETTINGS];
	dapar_tree_t tree;
	char utf8buf[4];
	int utf8buflen;
	int nextexceptid;
} dapar_stream_t;

#ifdef __cplusplus
extern "C" {
#endif

extern dapar_err_t  dapar_stream_init(dapar_stream_t *m,
				const dapar_rule_t *grammar);
extern void         dapar_stream_configure(dapar_stream_t *m,
				dapar_setting_t name, int value);
extern int          dapar_stream_configured(dapar_stream_t *m,
				dapar_setting_t name);
extern dapar_err_t  dapar_stream_reset(dapar_stream_t *m);
extern dapar_bool_t dapar_stream_matched(const dapar_stream_t *m);

extern dapar_err_t  dapar_stream_input_char(dapar_stream_t *m,
				dapar_unicode_t c);
extern dapar_err_t  dapar_stream_input_utf8(dapar_stream_t *m,
				const char *input, int size);
extern dapar_err_t  dapar_stream_input_raw(dapar_stream_t *m,
				const void *input, int size);
extern dapar_err_t  dapar_stream_input_utf32(dapar_stream_t *m,
				const dapar_ucs4_t *input, int size);

extern dapar_err_t  dapar_stream_end(dapar_stream_t *m,
				const dapar_tree_t **tree);
extern void         dapar_stream_copytree(dapar_stream_t *m,
				dapar_tree_t *tree);
extern void         dapar_stream_free(dapar_stream_t *m);

/* dapar_tree_free() is only for use with dapar_stream_copytree() */
extern void         dapar_tree_free(dapar_tree_t *t);

extern const char * dapar_err_string(dapar_err_t err);
extern const dapar_errorinfo_t * dapar_stream_errorinfo(dapar_stream_t *m);

extern const int dapar_version;

#ifdef __cplusplus
}
#endif

#endif
