/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapartest.h"

static const testcase_t testcase[] = {
	{"a = b;",
		"syntax{rule{"
			"ident'a',"
			"deflist{"
				"def{term{factor{primary{"
					"ident'b'"
				"}}}}"
			"}"
		"}}"
	},
	{"foo bar = pre, foo, bar, post;",
		"syntax{rule{"
			"ident'foo bar',"
			"deflist{def{"
				"term{factor{primary{ident'pre'}}},"
				"term{factor{primary{ident'foo'}}},"
				"term{factor{primary{ident'bar'}}},"
				"term{factor{primary{ident'post'}}}"
			"}}"
		"}}"
	},
	{"Some Truth Value = 'true' | 'false' (* Boolean *);",
		"syntax{rule{"
			"ident'Some Truth Value',"
			"deflist{"
				"def{term{factor{primary{"
					"terminal_string''true''"
				"}}}},"
				"def{term{factor{primary{"
					"terminal_string''false''"
				"}}}}"
			"},"
			"comment'(* Boolean *)'"
		"}}"
	},
	{"aaa = 3 * a;",
		"syntax{rule{"
			"ident'aaa',"
			"deflist{"
				"def{term{factor{"
					"integer'3',"
					"primary{ident'a'}"
				"}}}"
			"}"
		"}}"
	},
	{"confuse = x y,z|w,q|r,(a|b).",
		"syntax{rule{"
			"ident'confuse',"
			"deflist{"
				"def{"
					"term{factor{primary{ident'x y'}}},"
					"term{factor{primary{ident'z'}}}"
				"},"
				"def{"
					"term{factor{primary{ident'w'}}},"
					"term{factor{primary{ident'q'}}}"
				"},"
				"def{"
					"term{factor{primary{ident'r'}}},"
					"term{factor{primary{grouped{deflist{"
						"def{term{factor{primary{"
							"ident'a'"
						"}}}},"
						"def{term{factor{primary{"
							"ident'b'"
						"}}}}"
					"}}}}}"
				"}"
			"}"
		"}}"
	},
	{NULL, NULL}
};

DAPAR_EXTERN(syntax)

int main(int argc, char *argv[])
{
	return dapar_test_main(syntax, testcase, argc, argv);
}

