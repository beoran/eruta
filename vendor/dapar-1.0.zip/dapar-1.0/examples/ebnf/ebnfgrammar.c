/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 *
 * Sample DAPAR grammar for EBNF, as defined in:
 * ISO/IEC 14977:1996 section 8.1 -
 * http://www.iso.org/iso/catalogue_detail.htm?csnumber=26153
 */

#include "dapar.h"

DAPAR_TOKN(terminal_string) "'", DAPAR_CHAR("^'"), DAPAR_REPEAT_PREV(1), "'",
			DAPAR_OR,
			"\"", DAPAR_CHAR("^\""), DAPAR_REPEAT_PREV(1), "\"",
			DAPAR_END
DAPAR_ANON(comment_symbol) "*", DAPAR_CHAR("^)"),
			DAPAR_OR, DAPAR_CHAR("^*"), DAPAR_END
DAPAR_TOKN(comment)	"(*", DAPAR_OPTIONAL_NEXT(2),
				comment_symbol, DAPAR_REPEAT_PREV(1),
			"*)", DAPAR_END
DAPAR_ANON(SP)		DAPAR_SPACE, DAPAR_OR,
			DAPAR_SPACE, comment, DAPAR_REPEAT_PREV(2),
				DAPAR_SPACE, DAPAR_END
DAPAR_TOKN(integer)	DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(word)	DAPAR_CHAR("A-Za-z"), DAPAR_OPTIONAL_NEXT(2),
			DAPAR_CHAR("A-Za-z0-9"), DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_TOKN(ident)	word, DAPAR_OPTIONAL_NEXT(3),
				" ", word, DAPAR_REPEAT_PREV(2), DAPAR_END
DAPAR_TOKN(special)	"?", DAPAR_OPTIONAL_NEXT(2),
				DAPAR_CHAR("^?"), DAPAR_REPEAT_PREV(1),
			"?", DAPAR_END
DAPAR_EXTERN(deflist)
DAPAR_RULE(grouped)	"(", SP, deflist, SP, ")", DAPAR_END
DAPAR_RULE(repeated)	"{", SP, deflist, SP, "}",
			DAPAR_OR, "(:", SP, deflist, SP, ":)", DAPAR_END
DAPAR_RULE(optional)	"[", SP, deflist, SP, "]",
			DAPAR_OR, "(/", SP, deflist, SP, "/)", DAPAR_END
DAPAR_RULE(primary)	optional,	DAPAR_OR,
			repeated,	DAPAR_OR,
			grouped,	DAPAR_OR,
			ident,		DAPAR_OR,
			terminal_string,DAPAR_OR,
			special,	DAPAR_END
DAPAR_RULE(factor)	DAPAR_OPTIONAL_NEXT(4), integer, SP, "*", SP,
				primary, DAPAR_END
DAPAR_RULE(exception)	factor, DAPAR_END
DAPAR_RULE(term)	factor, DAPAR_OPTIONAL_NEXT(4),
				SP, "-", SP, exception, DAPAR_END
DAPAR_RULE(def)		term, DAPAR_OPTIONAL_NEXT(5),
				SP, ",", SP, term,DAPAR_REPEAT_PREV(4),
			DAPAR_END
DAPAR_RULE(deflist)	def, DAPAR_OPTIONAL_NEXT(5),
				SP, DAPAR_CHAR("|/!"), SP, def,
				DAPAR_REPEAT_PREV(4), DAPAR_END
DAPAR_RULE(rule)	ident, SP, "=", SP,
				 DAPAR_OPTIONAL_NEXT(2), deflist, SP,
				 DAPAR_CHAR(";."), DAPAR_END
DAPAR_RULE(syntax)	SP, rule, DAPAR_REPEAT_PREV(2), SP, DAPAR_END

