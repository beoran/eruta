/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */
/*
 * A simple example of parsing XML. Displays tags and attributes as a tree.
 */

#include <stdio.h>
#include <string.h>
#include "dapar.h"

DAPAR_EXTERN(document)
DAPAR_EXTERN(element)
DAPAR_EXTERN(EmptyElemTag)
DAPAR_EXTERN(STag)
DAPAR_EXTERN(ETag)
DAPAR_EXTERN(Attribute)
DAPAR_EXTERN(CharData)

static int all_space(const char *str)
{
	const char *s = str;
	while (*s) {
		char c = *s;
		if (c != ' ' && c != '\t' && c != '\r' && c != '\n')
			return 0;
		s++;
	}
	return 1;
}

static void print_indent(int n)
{
	if (n)
		printf("%*c", n*4, ' ');
}

static void walk_xml(const dapar_match_t *root)
{
	static int indent = 0;
	const dapar_match_t *elem = root;
	const char *stagname = "";
	while (elem != NULL) {
		if (elem->rule == EmptyElemTag || elem->rule == STag) {
			const dapar_match_t *name = elem->firstchild;
			const dapar_match_t *attr = name->nextsibling;
			print_indent(indent);
			printf("%s", name->text);
			if (attr != NULL)
				printf(" (");
			while (attr != NULL) {
				while (attr != NULL && attr->rule != Attribute)
					attr = attr->nextsibling;
				if (attr != NULL) {
					printf("%s=%s",
						attr->firstchild->text,
						attr->lastchild->text);
				}
				attr = attr->nextsibling;
				if (attr != NULL)
					printf(", ");
			}
			if (name->nextsibling != NULL)
				printf(")");
			printf("\n");
			if (elem->rule == STag) {
				stagname = elem->firstchild->text;
				print_indent(indent);
				printf("{\n");
				indent++;
			}
		} else if (elem->rule == CharData) {
			if (!all_space(elem->text)) {
				print_indent(indent);
				printf("\"%s\"\n", elem->text);
			}
		} else if (elem->rule == ETag) {
			const char *etagname = elem->firstchild->text;
			indent--;
			print_indent(indent);
			if (strcmp(etagname, stagname)) {
				printf("} WARNING: Expected end tag `%s' but "
					"found `%s'\n", stagname, etagname);
			} else {
				printf("}\n");
			}
		}
		walk_xml(elem->firstchild);
		elem = elem->nextsibling;
	}
}

int main(int argc, char *argv[])
{
	dapar_stream_t m;
	dapar_err_t err;

	if (argc > 1) {
		printf("Usage: %s < input.xml\n", argv[0]);
		return 1;
	}
	
	err = dapar_stream_init(&m, document);
	if (!err) {
		char buf[256];
		size_t got;
		do {
			got = fread(buf, 1, sizeof(buf), stdin);
			if (got)
				err = dapar_stream_input_utf8(&m, buf, got);
		} while (got && !err);
		if (!err) {
			const dapar_tree_t *tree;
			err = dapar_stream_end(&m, &tree);
			if (!err)
				walk_xml(tree->root);
		}
		dapar_stream_free(&m);
	}

	if (err) {
		const dapar_errorinfo_t *info = dapar_stream_errorinfo(&m);
		printf("Error: %s at line %d col %d\n",
			dapar_err_string(err),
			info->pos.line,
			info->pos.column
			);
	}

	return (int)err;
}

