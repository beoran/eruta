/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 *
 * Dapar implementation of:
 * Extensible Markup Language (XML) 1.0 (Fifth Edition)
 * http://www.w3.org/TR/2008/REC-xml-20081126/
 *
 * WARNING: XML is horrible and should never be used by anyone for anything.
 */

#include "dapar.h"

#define DAPAR_XML_VERSION(maj,min,edn,dap) \
	( ((maj) << 24) | ((min) << 16) | ((edn) << 8) | (dap) )

/* Current XML grammar version is 1.0 fifth edition, plus dapar fixes rev1 */
#define DAPAR_XML_CURRENT_VERSION DAPAR_XML_VERSION(1,0,5,1)

DAPAR_ANON(_S1)         DAPAR_CHAR(" \t\r\n"),
			DAPAR_END
DAPAR_ANON(S)           DAPAR_CHAR(" \t\r\n"), DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_TOKN(CharRef)	/* '&#' [0-9]+ ';' | '&#x' [0-9a-fA-F]+ ';' */
			"&#", DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1), ";",
			DAPAR_OR,
			"&#x", DAPAR_CHAR("0-9a-fA-F"),	DAPAR_REPEAT_PREV(1),
				";",
			DAPAR_END
DAPAR_ANON(NameStartChar)
			/* ":" | [A-Z] | "_" | [a-z] | [#xC0-#xD6] |
			   [#xD8-#xF6] | [#xF8-#x2FF] | [#x370-#x37D] |
			   [#x37F-#x1FFF] | [#x200C-#x200D] | [#x2070-#x218F] |
			   [#x2C00-#x2FEF] | [#x3001-#xD7FF] |
			   [#xF900-#xFDCF] | [#xFDF0-#xFFFD] |
			   [#x10000-#xEFFFF] */
			DAPAR_CHAR(":A-Z_a-z"
				"#xC0-#xD6"
				"#xD8-#xF6"
				"#xF8-#x2FF"
				"#x370-#x37D"
				"#x37F-#x1FFF"
				"#x200C-#x200D"
				"#x2070-#x218F"
				"#x2C00-#x2FEF"
				"#x3001-#xD7FF"
				"#xF900-#xFDCF"
				"#xFDF0-#xFFFD"
				"#x10000-#xEFFFF"),
			DAPAR_END
DAPAR_ANON(NameChar)	/* NameStartChar | "-" | "." | [0-9] | #xB7 |
			   [#x0300-#x036F] | [#x203F-#x2040] */
			NameStartChar,
			DAPAR_OR, DAPAR_CHAR("-.0-9"
				"#xB7"
				"#x0300-#x036F"
				"#x203F-#x2040"),
			DAPAR_END
DAPAR_TOKN(Name)	/* NameStartChar (NameChar)* */
			NameStartChar, DAPAR_OPTIONAL_NEXT(2),
				NameChar, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_RULE(Names)	/* Name (#x20 Name)* */
			Name, DAPAR_OPTIONAL_NEXT(3),
				" ", Name, DAPAR_REPEAT_PREV(2), DAPAR_END
DAPAR_TOKN(Nmtoken)	NameChar, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_RULE(Nmtokens)	Nmtoken, DAPAR_OPTIONAL_NEXT(3),
				" ", Nmtoken, DAPAR_REPEAT_PREV(2), DAPAR_END
DAPAR_TOKN(SystemLiteral) "\"", DAPAR_OPTIONAL_NEXT(2),
				DAPAR_CHAR("^\""), DAPAR_REPEAT_PREV(1), "\"",
			DAPAR_OR, "'", DAPAR_OPTIONAL_NEXT(2),
				DAPAR_CHAR("^'"), DAPAR_REPEAT_PREV(1), "'",
			DAPAR_END
DAPAR_ANON(PubidChar)	DAPAR_CHAR("- \r\na-zA-Z0-9'()+,./:=?;!*#@$_%"),
			DAPAR_END
DAPAR_ANON(_PubidCharExceptApos)
			PubidChar, DAPAR_EXCEPT, "'",
			DAPAR_END
DAPAR_TOKN(PubidLiteral) /* '"' PubidChar* '"' | "'" (PubidChar - "'")* "'" */
			"\"", DAPAR_OPTIONAL_NEXT(2),
				PubidChar, DAPAR_REPEAT_PREV(1),
			"\"",
			DAPAR_OR,
			"'", DAPAR_OPTIONAL_NEXT(2),
				_PubidCharExceptApos, DAPAR_REPEAT_PREV(1),
			"'",
			DAPAR_END
DAPAR_RULE(EntityRef)	/* '&' Name ';' */
			"&", Name, ";",
			DAPAR_END
DAPAR_RULE(Reference)	/* EntityRef | CharRef */
			EntityRef, DAPAR_OR, CharRef, DAPAR_END
DAPAR_RULE(PEReference)	/* '%' Name ';' */
			"%", Name, ";",
			DAPAR_END
DAPAR_ANON(_AttValueD)	DAPAR_CHAR("^<&\""), DAPAR_OR, Reference, DAPAR_END
DAPAR_ANON(_AttValueS)	DAPAR_CHAR("^<&'"), DAPAR_OR, Reference, DAPAR_END
DAPAR_TOKN(AttValue)	/* '"' ([^<&"] | Reference)* '"' |
			   "'" ([^<&'] | Reference)* "'" */
			"\"", DAPAR_OPTIONAL_NEXT(2),
				_AttValueD, DAPAR_REPEAT_PREV(1), "\"",
			DAPAR_OR, "'", DAPAR_OPTIONAL_NEXT(2),
				_AttValueS, DAPAR_REPEAT_PREV(1), "'",
			DAPAR_END
DAPAR_ANON(EntityValueD) DAPAR_CHAR("^%&\""),
			DAPAR_OR, PEReference,
			DAPAR_OR, Reference,
			DAPAR_END
DAPAR_ANON(EntityValueS) DAPAR_CHAR("^%&'"),
			DAPAR_OR, PEReference,
			DAPAR_OR, Reference,
			DAPAR_END
DAPAR_TOKN(EntityValue)	"\"", DAPAR_OPTIONAL_NEXT(2),
				EntityValueD, DAPAR_REPEAT_PREV(1), "\"",
			DAPAR_OR, "'", DAPAR_OPTIONAL_NEXT(2),
				EntityValueS, DAPAR_REPEAT_PREV(1), "'",
			DAPAR_END
DAPAR_ANON(Char)	/* #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] |
			   [#x10000-#x10FFFF] */
			DAPAR_CHAR("\t\r\n"
				"#x20-#xD7FF"
				"#xE000-#xFFFD"
				"#x10000-#x10FFFF"),
			DAPAR_END
DAPAR_ANON(_CharExceptDash) Char, DAPAR_EXCEPT, "-", DAPAR_END
DAPAR_TOKN(Comment)	/* '<!--' ((Char - '-') | ('-' (Char - '-')))* '-->' */
			"<!--", DAPAR_OPTIONAL_NEXT(4),
				DAPAR_OPTIONAL_NEXT(1), "-",
				_CharExceptDash,
				DAPAR_REPEAT_PREV(3),
			"-->", DAPAR_END
DAPAR_RULE(_PITarget1)	DAPAR_OPTIONAL_NEXT(2),
				NameChar, DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_RULE(PITarget)	/* Name - (('X' | 'x') ('M' | 'm') ('L' | 'l')) */
			Name,
			DAPAR_EXCEPT,
			DAPAR_CHAR("Xx"), DAPAR_CHAR("Mm"), DAPAR_CHAR("Ll"),
			DAPAR_END
DAPAR_ANON(_CharStar)	DAPAR_OPTIONAL_NEXT(2),
				Char, DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_TOKN(_CharStarExceptEndPI)
			_CharStar,
			DAPAR_EXCEPT,
			_CharStar, "?>", _CharStar,
			DAPAR_END
DAPAR_RULE(PI)		/* '<?' PITarget (S (Char* - (Char* '?>' Char*)))?
			   '?>' */
			"<?", PITarget, DAPAR_OPTIONAL_NEXT(2),
				S, _CharStarExceptEndPI,
			"?>", DAPAR_END
DAPAR_ANON(CDStart)	"<![CDATA[", DAPAR_END
DAPAR_TOKN(CData)	/* (Char* - (Char* ']]>' Char*)) */
			_CharStar, DAPAR_EXCEPT, _CharStar, "]]>", _CharStar,
			DAPAR_END
DAPAR_ANON(CDEnd)	"]]>", DAPAR_END
DAPAR_RULE(CDSect)	CDStart, CData, CDEnd, DAPAR_END
DAPAR_ANON(Eq)		/* S? '=' S? */
			DAPAR_OPTIONAL_NEXT(1), S,
			"=",
			DAPAR_OPTIONAL_NEXT(1), S,
			DAPAR_END
DAPAR_TOKN(VersionNum)	/* '1.' [0-9]+ */
			"1.", DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_ANON(_VersionNumQ) "'", VersionNum, "'",
			DAPAR_OR, "\"", VersionNum, "\"",
			DAPAR_END
DAPAR_RULE(VersionInfo)	/* S 'version' Eq ("'" VersionNum
			  "'" | '"' VersionNum '"') */
			S, "version", Eq, _VersionNumQ, DAPAR_END
DAPAR_TOKN(EncName)	/* [A-Za-z] ([A-Za-z0-9._] | '-')* */
			DAPAR_CHAR("A-Za-z"),
			DAPAR_OPTIONAL_NEXT(2),
				DAPAR_CHAR("-A-Za-z0-9._"),
				DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_ANON(_EncodingDecl1) "\"", EncName, "\"",
			DAPAR_OR, "'", EncName, "'",
			DAPAR_END
DAPAR_RULE(EncodingDecl) /* S 'encoding' Eq
			    ('"' EncName '"' | "'" EncName "'" ) */
			S, "encoding", Eq, _EncodingDecl1,
			DAPAR_END
DAPAR_TOKN(_bool)	"yes", DAPAR_OR, "no", DAPAR_END
DAPAR_ANON(_SDDecl)	"\"", _bool, "\"",
			DAPAR_OR, "'", _bool, "'",
			DAPAR_END
DAPAR_RULE(SDDecl)	/* S 'standalone' Eq (("'" ('yes' | 'no') "'")
			                    | ('"' ('yes' | 'no') '"')) */
			S, "standalone", Eq, _SDDecl, DAPAR_END
DAPAR_RULE(StringType)	/* 'CDATA' */
			"CDATA", DAPAR_END
DAPAR_RULE(TokenizedType) /* 'ID' | 'IDREF' | 'IDREFS' | 'ENTITY' |
			     'ENTITIES' | 'NMTOKEN' | 'NMTOKENS' */
			"ID",
			DAPAR_OR, "IDREF",
			DAPAR_OR, "IDREFS",
			DAPAR_OR, "ENTITY",
			DAPAR_OR, "ENTITIES",
			DAPAR_OR, "NMTOKEN",
			DAPAR_OR, "NMTOKENS",
			DAPAR_END
DAPAR_RULE(NotationType) /* 'NOTATION' S '(' S? Name (S? '|' S? Name)* S? ')'*/
			"NOTATION", S, "(",
			DAPAR_OPTIONAL_NEXT(1), S,
			Name,
			DAPAR_OPTIONAL_NEXT(7),
				DAPAR_OPTIONAL_NEXT(1), S,
				"|",
				DAPAR_OPTIONAL_NEXT(1), S,
				Name,
				DAPAR_REPEAT_PREV(6),
			DAPAR_OPTIONAL_NEXT(1), S,
			")",
			DAPAR_END
DAPAR_RULE(Enumeration)	/* '(' S? Nmtoken (S? '|' S? Nmtoken)* S? ')' */
			"(",
			DAPAR_OPTIONAL_NEXT(1), S,
			Nmtoken,
			DAPAR_OPTIONAL_NEXT(7),
				DAPAR_OPTIONAL_NEXT(1), S,
				"|",
				DAPAR_OPTIONAL_NEXT(1), S,
				Nmtoken,
				DAPAR_REPEAT_PREV(6),
			DAPAR_OPTIONAL_NEXT(1), S,
                        ")",
			DAPAR_END
DAPAR_RULE(EnumeratedType) /* NotationType | Enumeration */
			NotationType, DAPAR_OR, Enumeration, DAPAR_END
DAPAR_RULE(AttType)	/* StringType | TokenizedType | EnumeratedType */
			StringType,
			DAPAR_OR, TokenizedType,
			DAPAR_OR, EnumeratedType,
			DAPAR_END
DAPAR_RULE(DefaultDecl)	/* '#REQUIRED' | '#IMPLIED' |
			   (('#FIXED' S)? AttValue) */
			"#REQUIRED",
			DAPAR_OR,
			"#IMPLIED",
			DAPAR_OR,
			DAPAR_OPTIONAL_NEXT(2), "#FIXED", S,
			AttValue,
			DAPAR_END
DAPAR_RULE(AttDef)	/* S Name S AttType S DefaultDecl */
			S, Name, S, AttType, S, DefaultDecl,
			DAPAR_END
DAPAR_RULE(AttlistDecl)	/* '<!ATTLIST' S Name AttDef* S? '>' */
			"<!ATTLIST", S, Name,
			DAPAR_OPTIONAL_NEXT(2), AttDef, DAPAR_REPEAT_PREV(1),
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(ExternalID)	/* 'SYSTEM' S SystemLiteral
			   | 'PUBLIC' S PubidLiteral S SystemLiteral */
			"SYSTEM", S, SystemLiteral,
			DAPAR_OR,
			"PUBLIC", S, PubidLiteral, S, SystemLiteral,
			DAPAR_END
DAPAR_RULE(PublicID)	/* 'PUBLIC' S PubidLiteral */
			"PUBLIC", S, PubidLiteral,
			DAPAR_END
DAPAR_ANON(_NotationDecl1) ExternalID, DAPAR_OR, PublicID, DAPAR_END
DAPAR_RULE(NotationDecl) /* '<!NOTATION' S Name S (ExternalID | PublicID)
			      S? '>' */
			"<!NOTATION", S, Name, S, _NotationDecl1,
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(NDataDecl)	/* S 'NDATA' S Name */
			S, "NDATA", S, Name,
			DAPAR_END
DAPAR_RULE(EntityDef)	/* EntityValue | (ExternalID NDataDecl?) */
			EntityValue,
			DAPAR_OR,
			ExternalID, DAPAR_OPTIONAL_NEXT(1), NDataDecl,
			DAPAR_END
DAPAR_RULE(GEDecl)	/* '<!ENTITY' S Name S EntityDef S? '>' */
			"<!ENTITY", S, Name, S, EntityDef,
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(PEDef)	/* EntityValue | ExternalID */
			EntityValue, DAPAR_OR, ExternalID,
			DAPAR_END
DAPAR_RULE(PEDecl)	/* '<!ENTITY' S '%' S Name S PEDef S? '>' */
			"<!ENTITY", S, "%", S, Name, S, PEDef,
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(EntityDecl)	/* GEDecl | PEDecl */
			GEDecl, DAPAR_OR, PEDecl,
			DAPAR_END
DAPAR_EXTERN(elementdecl)
DAPAR_RULE(markupdecl)	/* elementdecl | AttlistDecl | EntityDecl |
			   NotationDecl | PI | Comment */
			elementdecl,
			DAPAR_OR, AttlistDecl,
			DAPAR_OR, EntityDecl,
			DAPAR_OR, NotationDecl,
			DAPAR_OR, PI,
			DAPAR_OR, Comment,
			DAPAR_END
DAPAR_ANON(_Ignore)	"<![", DAPAR_OR, "]]>", DAPAR_END
DAPAR_RULE(Ignore)	/* Char* - (Char* ('<![' | ']]>') Char*) */
			_CharStar,
			DAPAR_EXCEPT,
			_CharStar, _Ignore, _CharStar,
			DAPAR_END
DAPAR_RULE(ignoreSectContents) /* Ignore
			          ('<![' ignoreSectContents ']]>' Ignore)* */
			Ignore,
			DAPAR_OPTIONAL_NEXT(5),
				"<![",
				ignoreSectContents,
				"]]>",
				Ignore,
				DAPAR_REPEAT_PREV(4),
			DAPAR_END
DAPAR_RULE(ignoreSect)	/* '<![' S? 'IGNORE' S? '[' ignoreSectContents* ']]>'*/
			"<![",
			DAPAR_OPTIONAL_NEXT(1), S,
			"IGNORE",
			DAPAR_OPTIONAL_NEXT(1), S,
			"[",
			DAPAR_OPTIONAL_NEXT(2),
				ignoreSectContents, DAPAR_REPEAT_PREV(1),
			"]]>",
			DAPAR_END
DAPAR_EXTERN(extSubsetDecl)
DAPAR_RULE(includeSect)	/* '<![' S? 'INCLUDE' S? '[' extSubsetDecl ']]>' */
			"<![",
			DAPAR_OPTIONAL_NEXT(1), S,
			"INCLUDE",
			DAPAR_OPTIONAL_NEXT(1), S,
			"[",
			extSubsetDecl,
			"]]>",
			DAPAR_END
DAPAR_RULE(conditionalSect) /* includeSect | ignoreSect */
			includeSect, DAPAR_OR, ignoreSect, DAPAR_END
DAPAR_RULE(DeclSep)	/* PEReference | S */
/* XML errata:
 * This should be:         PEReference | #x20 | #x9 | #xD | #xA
 * http://lists.w3.org/Archives/Public/xml-editor/2011OctDec/0001.html
 */
#if DAPAR_XML_CURRENT_VERSION <= DAPAR_XML_VERSION(1,0,5,0)
			PEReference, DAPAR_OR, S, DAPAR_END
#else
			PEReference, DAPAR_OR, _S1, DAPAR_END
#endif
DAPAR_ANON(_extSubsetDecl) markupdecl,
			DAPAR_OR, conditionalSect,
			DAPAR_OR, DeclSep,
			DAPAR_END
DAPAR_RULE(extSubsetDecl) /* ( markupdecl | conditionalSect | DeclSep)* */
			DAPAR_OPTIONAL_NEXT(2),
				_extSubsetDecl, DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_RULE(TextDecl)	/* '<?xml' VersionInfo? EncodingDecl S? '?>' */
			"<?xml",
			DAPAR_OPTIONAL_NEXT(1), VersionInfo,
			EncodingDecl,
			DAPAR_OPTIONAL_NEXT(1), S,
			"?>",
			DAPAR_END
DAPAR_RULE(extSubset)	/* TextDecl? extSubsetDecl */
			DAPAR_OPTIONAL_NEXT(1), TextDecl,
			extSubsetDecl,
			DAPAR_END
DAPAR_ANON(_intSubset)	markupdecl, DAPAR_OR, DeclSep, DAPAR_END
DAPAR_RULE(intSubset)	/* (markupdecl | DeclSep)* */
			DAPAR_OPTIONAL_NEXT(2),
				_intSubset, DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_RULE(doctypedecl)	/* '<!DOCTYPE' S Name (S ExternalID)? S?
			   ('[' intSubset ']' S?)? '>' */
			"<!DOCTYPE", S, Name,
			DAPAR_OPTIONAL_NEXT(2), S, ExternalID,
			DAPAR_OPTIONAL_NEXT(1), S,
			DAPAR_OPTIONAL_NEXT(5),
				"[", intSubset, "]",
				DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(XMLDecl)	/* '<?xml' VersionInfo EncodingDecl? SDDecl? S? '?>' */
			"<?xml",
			VersionInfo,
			DAPAR_OPTIONAL_NEXT(1), EncodingDecl,
			DAPAR_OPTIONAL_NEXT(1), SDDecl,
			DAPAR_OPTIONAL_NEXT(1), S,
			"?>",
			DAPAR_END
DAPAR_RULE(Misc)	/* Comment | PI | S */
/* XML errata:
 * This should be:         Comment | PI | S1
 * http://lists.w3.org/Archives/Public/xml-editor/2011OctDec/0002.html
 */
			Comment,
			DAPAR_OR, PI,
#if DAPAR_XML_CURRENT_VERSION <= DAPAR_XML_VERSION(1,0,5,0)
			DAPAR_OR, S,
#else
			DAPAR_OR, _S1,
#endif
			DAPAR_END
DAPAR_RULE(prolog)	/* XMLDecl? Misc* (doctypedecl Misc*)? */
			DAPAR_OPTIONAL_NEXT(1), XMLDecl,
			DAPAR_OPTIONAL_NEXT(2), Misc, DAPAR_REPEAT_PREV(1),
			DAPAR_OPTIONAL_NEXT(4),
				doctypedecl,
				DAPAR_OPTIONAL_NEXT(2),
					Misc, DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_RULE(Attribute)	/* Name Eq AttValue */
			Name, Eq, AttValue,
			DAPAR_END
DAPAR_RULE(STag)	/* '<' Name (S Attribute)* S? '>' */
			"<",
			Name,
			DAPAR_OPTIONAL_NEXT(3),
				S, Attribute, DAPAR_REPEAT_PREV(2),
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(ETag)	/* '</' Name S? '>' */
			"</",
			Name,
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_EXTERN(element)
DAPAR_ANON(_content)	element,
			DAPAR_OR, Reference,
			DAPAR_OR, CDSect,
			DAPAR_OR, PI,
			DAPAR_OR, Comment,
			DAPAR_END
DAPAR_TOKN(CharData)	/* [^<&]* - ([^<&]* ']]>' [^<&]*) */
/* XML errata:
 * This should be:         [^<&]+ - ([^<&]* ']]>' [^<&]*)
 * http://lists.w3.org/Archives/Public/xml-editor/2011OctDec/0000.html
 */
#if DAPAR_XML_CURRENT_VERSION <= DAPAR_XML_VERSION(1,0,5,0)
			DAPAR_OPTIONAL_NEXT(2),
#endif
			DAPAR_CHAR("^<&"), DAPAR_REPEAT_PREV(1),
			DAPAR_EXCEPT,
			DAPAR_OPTIONAL_NEXT(2),
				DAPAR_CHAR("^<&"), DAPAR_REPEAT_PREV(1),
			"]]>",
			DAPAR_OPTIONAL_NEXT(2),
                                DAPAR_CHAR("^<&"), DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_RULE(content)	/* CharData? ((element | Reference | CDSect | PI |
			               Comment) CharData?)* */
			DAPAR_OPTIONAL_NEXT(1), CharData,
			DAPAR_OPTIONAL_NEXT(4),
				_content,
				DAPAR_OPTIONAL_NEXT(1), CharData,
				DAPAR_REPEAT_PREV(3),
			DAPAR_END
DAPAR_RULE(extParsedEnt) /* TextDecl? content */
			DAPAR_OPTIONAL_NEXT(1), TextDecl,
			content,
			DAPAR_END
DAPAR_RULE(EmptyElemTag) /* '<' Name (S Attribute)* S? '/>' */
			"<",
			Name,
			DAPAR_OPTIONAL_NEXT(3),
				S, Attribute, DAPAR_REPEAT_PREV(2),
			DAPAR_OPTIONAL_NEXT(1), S,
			"/>",
			DAPAR_END
DAPAR_EXTERN(cp)
DAPAR_RULE(choice)	/* '(' S? cp ( S? '|' S? cp )+ S? ')' */
			"(",
			DAPAR_OPTIONAL_NEXT(1), S,
			cp,
			DAPAR_OPTIONAL_NEXT(1), S, "|",
				DAPAR_OPTIONAL_NEXT(1), S,
				cp,
				DAPAR_REPEAT_PREV(6),
			DAPAR_OPTIONAL_NEXT(1), S,
			")",
			DAPAR_END
DAPAR_RULE(seq)		/* '(' S? cp ( S? ',' S? cp )* S? ')' */
			"(",
			DAPAR_OPTIONAL_NEXT(1), S,
			cp,
			DAPAR_OPTIONAL_NEXT(7),
				DAPAR_OPTIONAL_NEXT(1), S,
				",",
				DAPAR_OPTIONAL_NEXT(1), S,
				cp,
				DAPAR_REPEAT_PREV(6),
			DAPAR_OPTIONAL_NEXT(1), S,
			")",
			DAPAR_END
DAPAR_ANON(_children1)	choice, DAPAR_OR, seq, DAPAR_END
DAPAR_RULE(children)	/* (choice | seq) ('?' | '*' | '+')? */
			_children1,
			DAPAR_OPTIONAL_NEXT(1), DAPAR_CHAR("?*+"),
			DAPAR_END
DAPAR_ANON(_cp1)	Name, DAPAR_OR, choice, DAPAR_OR, seq, DAPAR_END
DAPAR_RULE(cp)		/* (Name | choice | seq) ('?' | '*' | '+')? */
			_cp1,
			DAPAR_OPTIONAL_NEXT(1), DAPAR_CHAR("?*+"),
			DAPAR_END
DAPAR_RULE(Mixed)	/* '(' S? '#PCDATA' (S? '|' S? Name)* S? ')*'
			   | '(' S? '#PCDATA' S? ')' */
			"(",
			DAPAR_OPTIONAL_NEXT(1), S,
			"#PCDATA",
			DAPAR_OPTIONAL_NEXT(7),
				DAPAR_OPTIONAL_NEXT(1), S,
				"|",
				DAPAR_OPTIONAL_NEXT(1), S,
				Name,
				DAPAR_REPEAT_PREV(6),
			DAPAR_OPTIONAL_NEXT(1), S,
			")*",
			DAPAR_OR,
			"(",
			DAPAR_OPTIONAL_NEXT(1), S,
			"#PCDATA",
			DAPAR_OPTIONAL_NEXT(1), S,
			")",
			DAPAR_END
DAPAR_RULE(contentspec) /* 'EMPTY' | 'ANY' | Mixed | children */
			"EMPTY",
			DAPAR_OR, "ANY",
			DAPAR_OR, Mixed,
			DAPAR_OR, children,
			DAPAR_END
DAPAR_RULE(elementdecl) /* '<!ELEMENT' S Name S contentspec S? '>' */
			"<!ELEMENT", S, Name, S, contentspec,
			DAPAR_OPTIONAL_NEXT(1), S,
			">",
			DAPAR_END
DAPAR_RULE(element)	/* EmptyElemTag | STag content ETag */
			EmptyElemTag,
			DAPAR_OR, STag, content, ETag,
			DAPAR_END
DAPAR_RULE(document)	prolog, element,
			DAPAR_OPTIONAL_NEXT(2),
				Misc, DAPAR_REPEAT_PREV(1),
			DAPAR_END
