/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapartest.h"

static const testcase_t testcase[] = {
	{"<?xml version=\"1.0\" encoding=\"UTF-8\" ?> <a></a>",
		"document{"
			"prolog{"
				"XMLDecl{"
					"VersionInfo{VersionNum'1.0'},"
					"EncodingDecl{EncName'UTF-8'}"
				"},"
				"Misc"
			"},"
			"element{STag{Name'a'},content,ETag{Name'a'}}"
		"}"
	},

	{"<?xml version=\"1.0\"?>\n"
	 "<quiz>\n"
 	"	<question>1 + 1 =</question>\n"
	"	<answer>2</answer>\n"
	"	<!-- Too difficult? -->\n"
	 "</quiz>\n"
	 ,
		"document{"
			"prolog{"
				"XMLDecl{VersionInfo{VersionNum'1.0'}},"
				"Misc"
			"},"
			"element{"
				"STag{Name'quiz'},"
				"content{"
					"CharData'\n\t',"
					"element{"
						"STag{Name'question'},"
						"content{CharData'1 + 1 ='},"
						"ETag{Name'question'}"
					"},"
					"CharData'\n\t',"
					"element{"
						"STag{Name'answer'},"
						"content{CharData'2'},"
						"ETag{Name'answer'}"
					"},"
					"CharData'\n\t',"
					"Comment'<!-- Too difficult? -->',"
					"CharData'\n'"
				"},"
				"ETag{Name'quiz'}"
			"},"
			"Misc"
		"}"
	},

	{"<trivial>Hello world!</trivial>",
		"document{"
			"prolog,"
			"element{"
				"STag{Name'trivial'},"
				"content{CharData'Hello world!'},"
				"ETag{Name'trivial'}"
			"}"
		"}"
	},

	{"<?xml version=\"2.0\" encoding=\"UTF-8\" ?> <a></a>",
		"Error at line 1 col 16: Unexpected character"
	},

	{"<?wtf You aren't allowed ?> in here ?> <abc/>",
		/* This should definitely give an error, but this one?... */
		"Error at line 1 col 46: Unexpected end of input"
	},

	{"<?wtf You are now following the rules ?> <abc/>",
		"document{"
			"prolog{"
				"Misc{PI{"
					"PITarget{Name'wtf'},"
					"_CharStarExceptEndPI'You are now "
						"following the rules '"
				"}},"
				"Misc"
			"},"
			"element{EmptyElemTag{Name'abc'}}"
		"}"
	},

	{"<thing>having ]]> inside CharData is invalid</thing>",
		"Error at line 1 col 45: Unexpected character"
	},

	{"<foo><bar>",
		"Error at line 1 col 11: Unexpected end of input"
	},

	{"<HTML><IMG align=\"left\" src='image.jpg' /></HTML>"
	 ,
		"document{"
			"prolog,"
			"element{"
				"STag{Name'HTML'},"
				"content{"
					"element{EmptyElemTag{"
						"Name'IMG',"
						"Attribute{"
							"Name'align',"
							"AttValue'\"left\"'"
						"},"
						"Attribute{"
							"Name'src',"
							"AttValue''image.jpg''"
						"}"
					"}}"
				"},"
				"ETag{Name'HTML'}"
			"}"
		"}"
	},

	{"<x/>",
		"document{prolog,element{EmptyElemTag{Name'x'}}}"
	},

	/* Regression test - reveals an ambiguous grammar */
	{"<!DOCTYPE root [  ]><x/>",
		"document{"
			"prolog{"
				"doctypedecl{Name'root',"
				            "intSubset{DeclSep,DeclSep}}"
			"},"
			"element{EmptyElemTag{Name'x'}}"
		"}"
	},

	/* Overlapping token matches - seems to be required by the grammar */
	{"<a b='1 &gt; 0'/>",
		"document{"
			"prolog,"
			"element{EmptyElemTag{"
				"Name'a',"
				"Attribute{Name'b',AttValue''1 &gt; 0''{"
					"Reference{EntityRef{Name'gt'}}"
				"}}"
			"}}"
		"}"
	},

	{"<x y='heiß und schön'/>",
		"document{"
			"prolog,"
			"element{EmptyElemTag{"
				"Name'x',"
				"Attribute{"
					"Name'y',"
					"AttValue''heiß und schön''"
				"}"
			"}}"
		"}"
	},

	{"<Straße Name='Easy' Länge='2km'>existiert nicht</Straße>",
		"document{"
			"prolog,"
			"element{"
				"STag{Name'Straße',"
				     "Attribute{Name'Name',AttValue''Easy''},"
				     "Attribute{Name'Länge',AttValue''2km''}"
				"},"
				"content{CharData'existiert nicht'},"
				"ETag{Name'Straße'}"
			"}"
		"}"
	},

	{"<!-- technically -- is not allowed in a comment -->",
		"Error at line 1 col 20: Unexpected character"
	},

	{"<Z/>  ",
		"document{prolog,element{EmptyElemTag{Name'Z'}},Misc,Misc}"
	},

	{"<?xml-Z?>\n"
	 "<Q></Q>\n",
		"document{"
			"prolog{"
				"Misc{PI{PITarget{Name'xml-Z'}}},"
				"Misc"
			"},"
			"element{"
				"STag{Name'Q'},"
				"content,"
				"ETag{Name'Q'}"
			"},"
			"Misc"
		"}"
	},

	{"<?xml version=\"1.0\"?>\n"
	 "<?xml-stylesheet href=\"foo.xsl\" type=\"text/xsl\"?>\n"
	 "<foo></foo>\n",
		"document{"
			"prolog{"
				"XMLDecl{VersionInfo{VersionNum'1.0'}},"
				"Misc,"
				"Misc{"
					"PI{"
						"PITarget{"
							"Name'xml-stylesheet'"
						"},"
						"_CharStarExceptEndPI"
							"'href=\"foo.xsl\" "
							"type=\"text/xsl\"'"
					"}"
				"},"
				"Misc"
			"},"
			"element{STag{Name'foo'},content,ETag{Name'foo'}},"
			"Misc"
		"}"
	},

	{NULL, NULL}
};

DAPAR_EXTERN(document)

int main(int argc, char *argv[])
{
	return dapar_test_main(document, testcase, argc, argv);
}

