/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapartest.h"

/*
 * This grammar is for testing regressions found in apps outside of dapar.
 * Don't expect it to make sense.
 */

DAPAR_TOKN(a)           DAPAR_CHAR("Aa"), DAPAR_END
DAPAR_RULE(var)         a, DAPAR_END
DAPAR_RULE(quest)       var, DAPAR_SPACE, "?", DAPAR_END
DAPAR_ANON(regression1) var, DAPAR_OR, quest, DAPAR_END

DAPAR_TOKN(b)           DAPAR_CHAR("Bb"), DAPAR_END
DAPAR_RULE(pre)         DAPAR_OR, DAPAR_END
DAPAR_RULE(post)        DAPAR_OR, DAPAR_END
DAPAR_EXTERN(expr)
DAPAR_RULE(group)       "(", pre, expr, ")", post, DAPAR_END
DAPAR_RULE(expr)        b, DAPAR_OR, group, DAPAR_END
DAPAR_ANON(regression2) expr, DAPAR_END

DAPAR_ANON(regressions) regression1, DAPAR_OR,
                        regression2, DAPAR_END

static const testcase_t testcase[] = {
	{"a",
		"var{a'a'}"
	},
	{"b",
		"expr{b'b'}"
	},
	{"b\n",
		"Error at line 2 col 0: Unexpected character"
	},
	{"(b)",
		"expr{group{pre,expr{b'b'},post}}"
	},
	{"(((b)))",
		"expr{group{"
			"pre,"
			"expr{group{"
				"pre,"
				"expr{group{"
					"pre,"
					"expr{b'b'},"
					"post"
				"}},"
				"post"
			"}},"
			"post"
		"}}"
	},
	{NULL, NULL}
};

int main(int argc, char *argv[])
{
	return dapar_test_main(regressions, testcase, argc, argv);
}

