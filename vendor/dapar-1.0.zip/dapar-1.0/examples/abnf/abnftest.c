/* 
 * Copyright (c) 2011-2012  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapartest.h"

static const testcase_t testcase[] = {
	{"a=b\r\n",
		"rulelist{rule{"
			"rulename'a',"
			"defined_as,"
			"elements{alternation{concatenation{"
			"repetition{element{"
				"rulename'b'"
			"}}}}}"
		"}}"
	},
	{"a=b/c\r\n",
		"rulelist{rule{"
			"rulename'a',"
			"defined_as,"
			"elements{alternation{"
				"concatenation{repetition{element{"
					"rulename'b'"
				"}}},"
				"concatenation{repetition{element{"
					"rulename'c'"
				"}}}"
			"}}"
		"}}"
	},
	{"a = b / c\r\n",
		"rulelist{rule{"
			"rulename'a',"
			"defined_as,"
			"elements{alternation{"
				"concatenation{repetition{element{"
					"rulename'b'"
				"}}},"
				"concatenation{repetition{element{"
					"rulename'c'"
				"}}}"
			"}}"
		"}}"
	},
	{"X=Y;Z\r\n",
		"rulelist{rule{"
			"rulename'X',"
			"defined_as,"
			"elements{alternation{concatenation{"
			"repetition{element{"
				"rulename'Y'"
			"}}}}},"
			"comment';Z\r\n'"
		"}}"
	},
	{"X=Y\r\n ;Z\r\n",
#ifdef STRICT_RFC5234
	/* http://www.rfc-editor.org/errata_search.php?rfc=5234&eid=2968 */
		"Error at line 1 col 3: Ambiguous grammar match detected"
#else
		"rulelist{"
			"rule{"
				"rulename'X',"
				"defined_as,"
				"elements{alternation{"
				"concatenation{repetition{element{"
					"rulename'Y'"
				"}}}}}"
			"},"
			"comment';Z\r\n'"
		"}"
#endif
	},
	{"fuzzy = \"true\" / \"false\" / \"maybe\"\r\n",
		"rulelist{rule{"
			"rulename'fuzzy',"
			"defined_as,"
			"elements{alternation{"
				"concatenation{repetition{element{"
					"char_val'\"true\"'"
				"}}},"
				"concatenation{repetition{element{"
					"char_val'\"false\"'"
				"}}},"
				"concatenation{repetition{element{"
					"char_val'\"maybe\"'"
				"}}}"
			"}}"
		"}}"
	},
	{"rulelist = 1*( rule / (*c-wsp c-nl) )\r\n",
		"rulelist{rule{"
			"rulename'rulelist',"
			"defined_as,"
			"elements{alternation{concatenation{repetition{"
				"repeat'1*',"
				"element{group{alternation{"
					"concatenation{repetition{element{"
						"rulename'rule'"
					"}}},"
					"concatenation{repetition{element{"
					  "group{alternation{concatenation{"
					  	"repetition{"
					  		"repeat'*',"
							"element{"
							   "rulename'c-wsp'"
							"}"
						"},"
						"repetition{element{"
							"rulename'c-nl'"
						"}}"
					"}}}}}}"
				"}}}"
			"}}}}"
		"}}"
	},
	{"Integer = 1*%x30-39\r\n",
		"rulelist{rule{"
			"rulename'Integer',"
			"defined_as,"
			"elements{alternation{concatenation{repetition{"
				"repeat'1*',"
				"element{num_val{hex_val'x30-39'}}"
			"}}}}"
		"}}"
	},
	{";\r\n ;\r\n",
#ifdef STRICT_RFC5234
	/* http://www.rfc-editor.org/errata_search.php?rfc=5234&eid=3076 */
		"Error at line 1 col 1: Ambiguous grammar match detected in anonymous match"
#else
		"rulelist{comment';\r\n',comment';\r\n'}"
#endif
	},
	{NULL, NULL}
};

DAPAR_EXTERN(rulelist)

int main(int argc, char *argv[])
{
	return dapar_test_main(rulelist, testcase, argc, argv);
}

