/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapar.h"

DAPAR_ANON(ALPHA)       DAPAR_CHAR("A-Za-z"), DAPAR_END
DAPAR_ANON(BIT)         DAPAR_CHAR("01"), DAPAR_END
DAPAR_ANON(DIGIT)       DAPAR_CHAR("0-9"), DAPAR_END
DAPAR_ANON(HEXDIG)      DAPAR_CHAR("0-9A-F"), DAPAR_END
DAPAR_ANON(SP)          " ", DAPAR_END
DAPAR_ANON(HTAB)        "\t", DAPAR_END
DAPAR_ANON(WSP)         SP, DAPAR_OR, HTAB, DAPAR_END
DAPAR_ANON(VCHAR)       DAPAR_CHAR("\x21-\x7e"), DAPAR_END
DAPAR_ANON(WSP_or_VCHAR) WSP, DAPAR_OR, VCHAR, DAPAR_END
DAPAR_ANON(CR)          "\r", DAPAR_END
DAPAR_ANON(LF)          "\n", DAPAR_END
#ifdef STRICT_RFC5234
DAPAR_ANON(CRLF)        CR, LF, DAPAR_END
#else
DAPAR_ANON(CRLF)        LF, DAPAR_OR, /* <-- nonstandard; support Unix text */
                        CR, LF, DAPAR_END
#endif
DAPAR_ANON(DQUOTE)      "\"", DAPAR_END
DAPAR_TOKN(comment)     ";", DAPAR_OPTIONAL_NEXT(2),
                            WSP_or_VCHAR, DAPAR_REPEAT_PREV(1), 
			    CRLF, DAPAR_END
DAPAR_ANON(c_nl)        comment, DAPAR_OR, CRLF, DAPAR_END
DAPAR_ANON(c_wsp)       WSP, DAPAR_OR, c_nl, WSP, DAPAR_END
DAPAR_ANON(star_c_wsp)  DAPAR_OR, c_wsp, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(onestar_c_wsp) c_wsp, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(star_DIGIT)  DAPAR_OR, DIGIT, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(onestar_DIGIT) DIGIT, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_EXTERN(alternation)
DAPAR_RULE(group)       "(", star_c_wsp, alternation, star_c_wsp, ")",
                            DAPAR_END
DAPAR_RULE(option)      "[", star_c_wsp, alternation, star_c_wsp, "]",
                            DAPAR_END
DAPAR_TOKN(char_val)    DQUOTE, DAPAR_OPTIONAL_NEXT(2),
                            DAPAR_CHAR("\x20-\x21\x23-\x7e"),
			    DAPAR_REPEAT_PREV(1), DQUOTE, DAPAR_END
DAPAR_ANON(onestar_BIT) BIT, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(bin_val1)    ".", onestar_BIT, DAPAR_REPEAT_PREV(2), DAPAR_OR,
                        "-", onestar_BIT, DAPAR_END
DAPAR_TOKN(bin_val)     "b", onestar_BIT,
                            DAPAR_OPTIONAL_NEXT(1), bin_val1, DAPAR_END
DAPAR_ANON(dec_val1)    ".", onestar_DIGIT, DAPAR_REPEAT_PREV(2), DAPAR_OR,
                        "-", onestar_DIGIT, DAPAR_END
DAPAR_TOKN(dec_val)     "d", onestar_DIGIT,
                            DAPAR_OPTIONAL_NEXT(1), dec_val1, DAPAR_END
DAPAR_ANON(onestar_HEXDIG) HEXDIG, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(hex_val1)    ".", onestar_HEXDIG, DAPAR_REPEAT_PREV(2), DAPAR_OR,
                        "-", onestar_HEXDIG, DAPAR_END
DAPAR_TOKN(hex_val)     "x", onestar_HEXDIG,
                            DAPAR_OPTIONAL_NEXT(1), hex_val1, DAPAR_END
DAPAR_TOKN(prose_val)   "<", DAPAR_OPTIONAL_NEXT(2),
                            DAPAR_CHAR("\x20-\x3d\x3f-\x7e"),
			    DAPAR_REPEAT_PREV(1), ">", DAPAR_END
DAPAR_ANON(num_val1)    bin_val, DAPAR_OR, dec_val, DAPAR_OR, hex_val,DAPAR_END
DAPAR_RULE(num_val)     "%", num_val1, DAPAR_END
DAPAR_ANON(rulename1)   ALPHA, DAPAR_OR, DIGIT, DAPAR_OR, "-", DAPAR_END
DAPAR_TOKN(rulename)    ALPHA, DAPAR_OPTIONAL_NEXT(2),
                            rulename1, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_RULE(element)     rulename, DAPAR_OR,
                        group, DAPAR_OR,
			option, DAPAR_OR,
			char_val, DAPAR_OR,
			num_val, DAPAR_OR,
			prose_val, DAPAR_END
DAPAR_TOKN(repeat)      onestar_DIGIT, DAPAR_OR,
                        star_DIGIT, "*", star_DIGIT, DAPAR_END
DAPAR_RULE(repetition)  DAPAR_OPTIONAL_NEXT(1), repeat, element, DAPAR_END
DAPAR_RULE(concatenation) repetition, DAPAR_OPTIONAL_NEXT(3),
                            onestar_c_wsp, repetition,
                            DAPAR_REPEAT_PREV(2), DAPAR_END
DAPAR_RULE(alternation) concatenation, DAPAR_OPTIONAL_NEXT(5),
                            star_c_wsp, "/", star_c_wsp, concatenation,
			    DAPAR_REPEAT_PREV(4), DAPAR_END
DAPAR_RULE(defined_as)  star_c_wsp, "=", DAPAR_OPTIONAL_NEXT(1), "/",
                            star_c_wsp, DAPAR_END
#if defined(STRICT_RFC5234)  /* this is ambiguous! */
DAPAR_RULE(elements)    alternation, star_c_wsp, DAPAR_END
DAPAR_RULE(rule)        rulename, defined_as, elements, c_nl, DAPAR_END
DAPAR_ANON(rulelist1)   rule, DAPAR_OR, star_c_wsp, c_nl, DAPAR_END
#else
DAPAR_ANON(star_WSP)    DAPAR_OR, WSP, DAPAR_REPEAT_PREV(1), DAPAR_END
/* http://www.rfc-editor.org/errata_search.php?rfc=5234&eid=2968 */
DAPAR_RULE(elements)    alternation, star_WSP, DAPAR_END
DAPAR_RULE(rule)        rulename, defined_as, elements, c_nl, DAPAR_END
/* New errata; not reported yet */
DAPAR_ANON(rulelist1)   rule, DAPAR_OR, star_WSP, c_nl, DAPAR_END
#endif
DAPAR_RULE(rulelist)    rulelist1, DAPAR_REPEAT_PREV(1), DAPAR_END
