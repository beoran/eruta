/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#define STRICT_RFC5234
#include "abnfgrammar.c"
#include "abnftest.c"

