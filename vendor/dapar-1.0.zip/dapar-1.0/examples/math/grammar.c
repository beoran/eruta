/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapar.h"
#include "./grammar.h"

/*
 * If you want a simpler example of a math grammar, look at simplegrammar.c
 */

/*
 * space0 coule be implemented with "DAPAR_SPACE", but using
 * DAPAR_OPTIONAL_NEXT instead gives test coverage for dapar's matchedempty
 * logic, which otherwise doesn't seem to be exercised.
 */
DAPAR_BEGIN(space0, 0, ANONYMOUS) /* 0 or more space characters */
		DAPAR_OPTIONAL_NEXT(2),
			DAPAR_CHAR(" \t\r\n"), DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_BEGIN(space1, 0, ANONYMOUS) /* 1 or more space characters */
		DAPAR_CHAR(" \t\r\n"), DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_BEGIN(muldiv, MATH_MULDIV, TOKEN)
		DAPAR_CHAR("*/"),  DAPAR_END
DAPAR_BEGIN(plumin, MATH_PLUMIN, TOKEN)
		DAPAR_CHAR("-+"),  DAPAR_END
DAPAR_BEGIN(variable, MATH_VARIABLE, TOKEN)
		DAPAR_CHAR("A-Za-z_"), DAPAR_OPTIONAL_NEXT(2),
		    DAPAR_CHAR("A-Za-z_0-9"), DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_BEGIN(number, MATH_NUMBER, TOKEN)
		DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1),
			DAPAR_OPTIONAL_NEXT(3),
			".", DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_BEGIN(previous, MATH_PREVIOUS, RULE)
		"%", DAPAR_END
DAPAR_BEGIN(symbol, 0, ANONYMOUS)
		previous, DAPAR_END
DAPAR_EXTERN(expr)
DAPAR_BEGIN(group, 0, ANONYMOUS)
		"{", space0, expr, space0, "}", DAPAR_OR,
		"[", space0, expr, space0, "]", DAPAR_OR,
		"(", space0, expr, space0, ")", DAPAR_END
DAPAR_BEGIN(preexponent, 0, ANONYMOUS)
		number,   DAPAR_OR,
		variable, DAPAR_OR,
		symbol,   DAPAR_OR,
		group,    DAPAR_END
DAPAR_EXTERN(preproduct)
DAPAR_EXTERN(adjacent)
DAPAR_EXTERN(signed_)
DAPAR_BEGIN(adjacentproduct, MATH_PRODUCT, RULE)
		adjacent, DAPAR_END
DAPAR_BEGIN(power, 0, ANONYMOUS)
		preproduct, DAPAR_OR,
		adjacentproduct,   DAPAR_OR,
		signed_,    DAPAR_END
DAPAR_BEGIN(raised, 0, ANONYMOUS)
		space0, "^", space0, power, DAPAR_END
DAPAR_BEGIN(nexponent, MATH_EXPONENT, RULE)
		number, raised, DAPAR_END
DAPAR_BEGIN(vexponent, MATH_EXPONENT, RULE)
		variable, raised, DAPAR_END
DAPAR_BEGIN(gexponent, MATH_EXPONENT, RULE)
		group, raised, DAPAR_END
DAPAR_BEGIN(sexponent, MATH_EXPONENT, RULE)
		symbol, raised, DAPAR_END
DAPAR_BEGIN(exponent, MATH_EXPONENT, RULE)
		preexponent, raised, DAPAR_END
DAPAR_EXTERN(vadjacent)
DAPAR_EXTERN(gadjacent)
DAPAR_EXTERN(sadjacent)
DAPAR_EXTERN(adjacent)
DAPAR_BEGIN(nadjacent, 0, ANONYMOUS)
		number, space1, number,    DAPAR_OR,
		number, space1, nadjacent, DAPAR_OR,
		number, space1, nexponent, DAPAR_OR,
		number, space0, variable,  DAPAR_OR,
		number, space0, symbol,    DAPAR_OR,
		number, space0, group,     DAPAR_OR,
		number, space0, vadjacent, DAPAR_OR,
		number, space0, gadjacent, DAPAR_OR,
		number, space0, gexponent, DAPAR_OR,
		number, space0, sexponent, DAPAR_OR,
		number, space0, vexponent, DAPAR_END
DAPAR_BEGIN(vadjacent, 0, ANONYMOUS)
		variable, space1, variable,  DAPAR_OR,
		variable, space1, number,    DAPAR_OR,
		variable, space0, symbol,    DAPAR_OR,
		variable, space0, group,     DAPAR_OR,
		variable, sexponent,         DAPAR_OR,
		variable, gexponent,         DAPAR_OR,
		variable, space1, exponent,  DAPAR_OR,
		variable, space1, adjacent,  DAPAR_OR,
		variable, sadjacent,         DAPAR_OR,
		variable, gadjacent,         DAPAR_END
DAPAR_EXTERN(multiplicand)
DAPAR_BEGIN(gadjacent, 0, ANONYMOUS)
		group, space0, multiplicand, DAPAR_END
DAPAR_BEGIN(sadjacent, 0, ANONYMOUS)
		symbol, space0, multiplicand, DAPAR_END
DAPAR_BEGIN(adjacent, 0, ANONYMOUS)
		nadjacent, DAPAR_OR,
		vadjacent, DAPAR_OR,
		sadjacent, DAPAR_OR,
		gadjacent, DAPAR_END
DAPAR_BEGIN(preproduct, 0, ANONYMOUS)
		preexponent, DAPAR_OR,
		exponent,    DAPAR_END
DAPAR_BEGIN(multiplicand, 0, ANONYMOUS)
		preproduct,  DAPAR_OR,
		adjacent, DAPAR_END
DAPAR_BEGIN(product, MATH_PRODUCT, RULE)
		adjacent, DAPAR_OR,
		multiplicand, space0, muldiv, space0, multiplicand,
			DAPAR_REPEAT_PREV(4), DAPAR_END
DAPAR_EXTERN(presum)
DAPAR_BEGIN(signed_, MATH_SIGNED, RULE)
		plumin, presum, DAPAR_END
DAPAR_BEGIN(presum, 0, ANONYMOUS)
		preproduct,  DAPAR_OR,
		product,     DAPAR_OR,
		signed_,     DAPAR_END
DAPAR_BEGIN(sum, MATH_SUM, RULE)
		presum, space0, plumin, space0, presum, DAPAR_REPEAT_PREV(4),
			DAPAR_END
DAPAR_BEGIN(expr, 0, ANONYMOUS)
		presum, DAPAR_OR,
		sum,    DAPAR_END
DAPAR_BEGIN(assignment, MATH_ASSIGNMENT, RULE)
		variable, space0, "=", space0, expr, DAPAR_END
DAPAR_BEGIN(statement, 0, ANONYMOUS)
		expr,       DAPAR_OR,
		assignment, DAPAR_END
DAPAR_BEGIN(math, 0, ANONYMOUS)
		space0, statement, space0, DAPAR_END

