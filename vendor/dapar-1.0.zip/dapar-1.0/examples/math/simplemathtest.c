/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapartest.h"

DAPAR_EXTERN(math)

static const testcase_t testcase[] = {
	{"7",   "number'7'"},
	{"123", "number'123'"},
	{"",    "Error at line 1 col 1: Unexpected end of input"},
	{"789+","Error at line 1 col 5: Unexpected end of input"},
	{"1+2", "sum{number'1',plumin'+',number'2'}"},
	{"1 + 2 + 3", "sum{number'1',plumin'+',number'2',plumin'+',"
	                       "number'3'}"},
	{"(1+2)","sum{number'1',plumin'+',number'2'}"},
	{"1+2+3+4+5+6+7+8+9",
		"sum{number'1',plumin'+',"
		    "number'2',plumin'+',"
		    "number'3',plumin'+',"
		    "number'4',plumin'+',"
		    "number'5',plumin'+',"
		    "number'6',plumin'+',"
		    "number'7',plumin'+',"
		    "number'8',plumin'+',"
		    "number'9'}"},
	{"4+5*6","sum{number'4',plumin'+',product{number'5',muldiv'*',"
	                                              "number'6'}}"},
	{"99 * (88 + 77) - 66 / 55",
		"sum{product{number'99',muldiv'*',"
		            "sum{number'88',plumin'+',number'77'}},"
		    "plumin'-',"
		    "product{number'66',muldiv'/',number'55'}}"},
	{"123:456", "Error at line 1 col 4: Unexpected character"},
	{"(((987654321)))", "number'987654321'"},
	{"(123 + 456 / 78))", "Error at line 1 col 17: Unexpected character"},
	{"x^y", "exponent{variable'x',variable'y'}"},
	{"1*2^3^4/5", "product{number'1',muldiv'*',"
	                      "exponent{number'2',"
	                               "exponent{number'3',number'4'}},"
	                      "muldiv'/',number'5'}"},
	{NULL, NULL}
};

int main(int argc, char *argv[])
{
	return dapar_test_main(math, testcase, argc, argv);
}

