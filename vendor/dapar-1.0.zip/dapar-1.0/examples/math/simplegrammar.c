/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapar.h"
#include "./grammar.h"

#define space0 DAPAR_SPACE
DAPAR_BEGIN(muldiv, MATH_MULDIV, TOKEN)
		DAPAR_CHAR("*/"),  DAPAR_END
DAPAR_BEGIN(plumin, MATH_PLUMIN, TOKEN)
		DAPAR_CHAR("-+"),  DAPAR_END
DAPAR_BEGIN(variable, MATH_VARIABLE, TOKEN)
		DAPAR_CHAR("A-Za-z_"), DAPAR_OPTIONAL_NEXT(2),
		    DAPAR_CHAR("A-Za-z_0-9"), DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_BEGIN(number, MATH_NUMBER, TOKEN)
		DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1),
			DAPAR_OPTIONAL_NEXT(3),
			".", DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1),
			DAPAR_END
DAPAR_EXTERN(expr)
DAPAR_BEGIN(group, 0, ANONYMOUS)
		"(", space0, expr, space0, ")", DAPAR_END
DAPAR_BEGIN(preexponent, 0, ANONYMOUS)
		number,   DAPAR_OR,
		variable, DAPAR_OR,
		group,    DAPAR_END
DAPAR_EXTERN(preproduct)
DAPAR_BEGIN(exponent, MATH_EXPONENT, RULE)
		preexponent, space0, "^", space0, preproduct, DAPAR_END
DAPAR_BEGIN(preproduct, 0, ANONYMOUS)
		preexponent, DAPAR_OR,
		exponent,    DAPAR_END
DAPAR_BEGIN(product, MATH_PRODUCT, RULE)
		preproduct, space0, muldiv, space0, preproduct,
			DAPAR_REPEAT_PREV(4), DAPAR_END
DAPAR_EXTERN(presum)
DAPAR_BEGIN(signed_, MATH_SIGNED, RULE)
		plumin, presum, DAPAR_END
DAPAR_BEGIN(presum, 0, ANONYMOUS)
		preproduct,  DAPAR_OR,
		product,     DAPAR_OR,
		signed_,     DAPAR_END
DAPAR_BEGIN(sum, MATH_SUM, RULE)
		presum, space0, plumin, space0, presum, DAPAR_REPEAT_PREV(4),
			DAPAR_END
DAPAR_BEGIN(expr, 0, ANONYMOUS)
		presum, DAPAR_OR,
		sum,    DAPAR_END
DAPAR_BEGIN(assignment, MATH_ASSIGNMENT, RULE)
		variable, space0, "=", space0, expr, DAPAR_END
DAPAR_BEGIN(statement, 0, ANONYMOUS)
		expr,       DAPAR_OR,
		assignment, DAPAR_END
DAPAR_BEGIN(math, 0, ANONYMOUS)
		space0, statement, space0, DAPAR_END

