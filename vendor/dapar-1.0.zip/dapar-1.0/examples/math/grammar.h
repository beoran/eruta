/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#ifndef __DAPAR_MATH_H__
#define __DAPAR_MATH_H__

typedef enum {
	MATH_MULDIV,
	MATH_PLUMIN,
	MATH_VARIABLE,
	MATH_NUMBER,
	MATH_SIGNED,
	MATH_EXPONENT,
	MATH_PRODUCT,
	MATH_SUM,
	MATH_ASSIGNMENT,
	MATH_PREVIOUS,
	MATH_TAGS
} math_tag_t;

#endif
