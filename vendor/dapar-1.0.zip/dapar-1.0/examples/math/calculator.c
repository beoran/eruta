/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include <stdio.h>  /* for fgets() */
#include <stdlib.h> /* for exit() */
#include <string.h> /* for strcmp() */
#include <math.h>
#include "dapar.h"
#include "./grammar.h"

#if !defined(NAN)
static union {unsigned long ul[2]; double d;} _NAN = {0xffffffff, 0x7fffffff};
#define NAN (_NAN.d)
#endif

DAPAR_EXTERN(math)

typedef double value_t;

typedef struct {
	char *name;
	value_t value;
} variable_t;

static value_t previous;
static variable_t var[20];
static int vars = 0;

static variable_t *find_variable(const char *name)
{
	int i;
	for (i=0; i < vars; i++) {
		if (!strcmp(var[i].name, name)) {
			return var + i;
		}
	}
	return NULL;
}

static value_t get_variable(const char *name)
{
	value_t result = NAN;
	variable_t *v = find_variable(name);
	if (v == NULL) {
		printf("variable '%s' does not exist\n", name);
	} else {
		result = v->value;
	}
	return result;
}

static char *strdupe(const char *oldstr)
{
	size_t len = strlen(oldstr);
	char *newstr = malloc(len + 1);
	if (newstr != NULL) {
		memcpy(newstr, oldstr, len+1);
	}
	return newstr;
}

static value_t set_variable(const char *name, value_t value)
{
	variable_t *v = find_variable(name);
	value_t result = value;
	if (v != NULL) {
		v->value = value;
	} else if (vars < sizeof(var)/sizeof(var[0])) {
		v = var + vars;
		vars++;
		v->name = strdupe(name);
		v->value = value;
	} else {
		printf("Too many variables defined already (%d)\n", vars);
		result = NAN;
	}
	return result;
}

static value_t eval(const dapar_match_t *match);

static value_t eval_product(const dapar_match_t *match)
{
	const dapar_match_t *child = match->firstchild;
	char op = '*';
	value_t total = 1;
	while (child != NULL) {
		value_t subvalue;
		subvalue = eval(child);
		if (op == '*') {
			total *= subvalue;
		} else {
			if (subvalue == 0.0) {
				return NAN;
			}
			total /= subvalue;
		}
		child = child->nextsibling;
		if (child == NULL) break;
		if (child->rule->tag == MATH_MULDIV) {
			op = child->text[0];
			child = child->nextsibling;
		} else {
			op = '*';
		}
	}
	return total;
}

static value_t eval_sum(const dapar_match_t *match)
{
	const dapar_match_t *child = match->firstchild;
	char sign = '+';
	value_t total = 0.0;
	while (child != NULL) {
		value_t subvalue;
		subvalue = eval(child);
		if (sign == '-') {
			total -= subvalue;
		} else {
			total += subvalue;
		}
		child = child->nextsibling;
		if (child == NULL || child->rule->tag != MATH_PLUMIN) break;
		sign = child->text[0];
		child = child->nextsibling;
	}
	return total;
}

static value_t eval(const dapar_match_t *match)
{
	value_t val = NAN;
	switch (match->rule->tag) {
	case MATH_VARIABLE:
		val = get_variable(match->text);
		break;
	case MATH_NUMBER:
		if (sscanf(match->text, "%lf", &val) != 1)
			val = NAN;
		break;
	case MATH_SIGNED:
		val = eval(match->lastchild);
		if (match->firstchild->text[0] == '-')
			val = -val;
		break;
	case MATH_EXPONENT: {
		value_t base, power;
		base = eval(match->firstchild);
		power = eval(match->lastchild);
		val = pow(base, power);
		} break;
	case MATH_PRODUCT:
		val = eval_product(match);
		break;
	case MATH_SUM:
		val = eval_sum(match);
		break;
	case MATH_ASSIGNMENT:
		val = set_variable(match->firstchild->text,
			eval(match->lastchild));
		break;
	case MATH_PREVIOUS:
		val = previous;
		break;
	default:
		val = NAN;
		break;
	}
	return val;
}

int main(void)
{
	dapar_err_t err;
	dapar_stream_t stream;
	const dapar_tree_t *tree;
	char line[512];
	int i;

	previous = NAN;

	err = dapar_stream_init(&stream, math);
	if (err) {
		printf("Fatal error: %s\n", dapar_err_string(err));
		return 1;
	}

	for (;;) {
		static const char prompt[] = "calculator> ";
		printf(prompt);
		while ( !err && fgets(line, sizeof(line), stdin) != NULL ) {
			err = dapar_stream_input_utf8(&stream, line, -1);
			if (!err && dapar_stream_matched(&stream)) {
				break;
			}
		}
		if (!err) {
			err = dapar_stream_end(&stream, &tree);
			if (!err) {
				value_t val = eval(tree->root);
				if (val == floor(val)) {
					printf("= %.0f\n", val);
				} else {
					printf("= %f\n", val);
				}
				previous = val;
			}
		}
		if (feof(stdin)) {
			printf("\n");
			break;
		}
		if (err) {
			const dapar_errorinfo_t *error =
				dapar_stream_errorinfo(&stream);
			int arrowpos = error->pos.column;
			if (error->pos.line == 1)
				arrowpos += sizeof(prompt) - 1;
			printf("%*c\n"
				"Error at line %d col %d: %s\n",
				arrowpos, '^',
				error->pos.line, error->pos.column,
				dapar_err_string(err));
			err = 0;
		}
		err = dapar_stream_reset(&stream);
	}

	dapar_stream_free(&stream);

	for (i = 0; i < vars; i++) {
		free(var[i].name);
		var[i].name = NULL;
	}

	return 0;
}
