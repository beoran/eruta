/* 
 * Copyright (c) 2011  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#include "dapartest.h"

/*
 * This grammar is for testing detection of invalid or poorly designed
 * grammars. Don't expect it to make sense.
 */

DAPAR_ANON(spacenc)     DAPAR_CHAR(" \t\r\n"), DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(comment)     ";", DAPAR_OPTIONAL_NEXT(2),
                            DAPAR_CHAR("^\n"), DAPAR_REPEAT_PREV(1),
                        "\n", DAPAR_END
DAPAR_ANON(spaceseg)    spacenc, DAPAR_OR,
                        comment, DAPAR_END
DAPAR_ANON(space1)      spaceseg, DAPAR_REPEAT_PREV(1), DAPAR_END
DAPAR_ANON(space0)      DAPAR_OR, space1, DAPAR_END

DAPAR_TOKN(ident)       DAPAR_CHAR("A-Za-z_"), DAPAR_OPTIONAL_NEXT(2),
                                DAPAR_CHAR("A-Za-z_0-9"), DAPAR_REPEAT_PREV(1),
                        DAPAR_END
DAPAR_RULE(variable)    ident,  DAPAR_END
DAPAR_TOKN(number)      DAPAR_CHAR("0-9"), DAPAR_REPEAT_PREV(1), DAPAR_END
/* Rule "pi" demonstrates an ambiguity error (conflicts with variable) */
DAPAR_RULE(pi)          "pi",  DAPAR_END
/* Rules "hashed" and "percentage" demonstrate overlapping token errors */
DAPAR_TOKN(hashed)      "#", ident,  DAPAR_END
DAPAR_TOKN(percentage)  number, "%",  DAPAR_END
DAPAR_ANON(expr)        percentage, DAPAR_OR,
                        hashed,     DAPAR_OR,
                        pi,         DAPAR_OR,
                        number,     DAPAR_OR,
                        variable,   DAPAR_END
DAPAR_RULE(lang)        space0, expr, space0,  DAPAR_END

static const testcase_t testcase[] = {
	{"p", "lang{variable{ident'p'}}"},
	{"pi", "Error at line 1 col 1: Ambiguous grammar match detected"},
	{"pie", "lang{variable{ident'pie'}}"},
	{"50", "lang{number'50'}"},
	{"50%", "lang{percentage'50%'{number'50'}}"},
	{"#blah", "lang{hashed'#blah'{ident'blah'}}"},
	{"1  ; a\n", "Error at line 1 col 2: Ambiguous grammar match detected in anonymous match"},
	{"123  ; Should work\n", "Error at line 1 col 4: Ambiguous grammar match detected in anonymous match"},
	{NULL, NULL}
};

int main(int argc, char *argv[])
{
	return dapar_test_main(lang, testcase, argc, argv);
}

