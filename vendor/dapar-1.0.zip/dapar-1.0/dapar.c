/* 
 * Copyright (c) 2011-2012  Daniel van Vugt <danv@users.sf.net> 
 * All rights reserved.  See LICENSE.txt for details. 
 */

#define FASTFORWARD_ENABLED 1  /* Slightly boosts performance. Not always. */

#if defined(DEBUGPRINT)
#include <stdio.h>
#define DPRINTF(arglist) printf arglist
#else
#define DPRINTF(arglist) {}
#endif
#include <stdlib.h> /* for realloc */
#include <string.h> /* for memcpy */
#include <assert.h>
#include "dapar.h"

#define INIT_QUEUE_MAX  32
#define INIT_MAXMATCHES 32
#define INIT_TEXTMAX    256

#define UNICODE_INVALID 0x80000000
#define NOMOREINPUT     UNICODE_INVALID

const int dapar_version = DAPAR_HEADER_VERSION;
const char dapar_copyright[] =
	"Dapar: Copyright (c) 2011-2012 Daniel van Vugt <danv@users.sf.net>";

static const char * const dapar_err_str[] = {
	/* [DAPAR_SUCCESS]       = */ "No error",
	/* [DAPAR_ERR_MEM]       = */ "Out of memory",
	/* [DAPAR_ERR_CHAR]      = */ "Unexpected character",
	/* [DAPAR_ERR_MULTIBYTE] = */ "Invalid multi-byte character",
	/* [DAPAR_ERR_EOS]       = */ "Unexpected end of input",
	/* [DAPAR_ERR_BADRULE]   = */ "Error in DAPAR_RULE encoding",
	/* [DAPAR_ERR_ARG]       = */ "Invalid argument to dapar API call",
	/* [DAPAR_ERR_AMBIGUOUS] = */ "Ambiguous grammar match detected"
};

#define UTF8_DECODE_LEN(_s) \
	( \
	((_s)[0] < 0x80) ? 1 : \
	(((_s)[0] & 0xE0) == 0xC0) ? 2 : \
	(((_s)[0] & 0xF0) == 0xE0) ? 3 : \
	(((_s)[0] & 0xF8) == 0xF0) ? 4 : 0 \
	)
	
static dapar_unicode_t decode_utf8(const char **p)
/*
 * Decode and return the UTF-8 character at **p, also incrementing *p to point
 * to the next character.
 *
 * Returns UNICODE_INVALID on error. Still increments *p on error.
 */
{
	dapar_byte_t b0 = **(const dapar_byte_t**)p;
	int len = UTF8_DECODE_LEN(&b0);
	dapar_unicode_t u;
	if (len == 1) {
		u = b0;
	} else if (len > 1) {
		int i;
		u = b0 & (0x7F >> len);
		for (i = 1; i < len; i++) {
			dapar_byte_t bi = (*(const dapar_byte_t**)p)[i];
			if ((bi & 0xC0) != 0x80) {
				len = i + 1;
				u = UNICODE_INVALID;
				break;
			}
			u = (u << 6) | ((dapar_unicode_t)bi & 0x3F);
		}
	} else {
		u = UNICODE_INVALID;
		len = 1;
	}
	*p += len;
	return u;
}

#define UTF8_ENCODE_LEN(_c) \
	( \
	(_c) < 0x80 ? 1 : \
	(_c) < 0x800 ? 2 : \
	(_c) < 0x10000 ? 3 : \
	(_c) < 0x110000 ? 4 : 0 \
	)

static int encode_utf8(dapar_unicode_t c, char *p)
/*
 * Encode unicode character c into UTF-8 at p (which must point to at least
 * 4 characters). Returns the encoded character length in bytes, or zero
 * on error.
 */
{
	int len = UTF8_ENCODE_LEN(c);
	if (len == 1) {
		*p = (char)c;
	} else if (len > 1) {
		int i;
		dapar_unicode_t u = c;
		for (i = len - 1; i > 0; i--) {
			p[i] = (char)(0x80 | (u & 0x3F));
			u >>= 6;
		}
		p[0] = ((char)'\x80' >> ((char)len - 1)) | (char)u;
	}
	return len;
}

static void locate_ambiguity(dapar_stream_t *m);

static dapar_err_t grow_queues(dapar_stream_t *m)
{
	dapar_state_t *bigger;
	int oldmax = m->queue[0].max;
	int newmax = oldmax <= 0 ? INIT_QUEUE_MAX :
#ifdef DEBUGHEAP
		oldmax + 1;
#else
		oldmax * 2;
#endif
	if (newmax >= m->setting[DAPAR_MAXSTATES]) {
		locate_ambiguity(m);
		return DAPAR_ERR_AMBIGUOUS;
	}
	bigger = (dapar_state_t*)realloc(m->queue[0].state,
			newmax * 2 * sizeof(dapar_state_t));
	if (bigger == NULL)
		return DAPAR_ERR_MEM;
	m->queue[0].state = bigger;
	m->queue[1].state = bigger + newmax;
	if (oldmax) {
#ifdef DEBUGHEAP
		memmove
#else
		memcpy
#endif
			(m->queue[1].state, bigger+oldmax,
			m->queue[1].size * sizeof(dapar_state_t));
	}
	m->queue[0].max = newmax;
	m->queue[1].max = newmax;
	return DAPAR_SUCCESS;
}

static int find_in_current(dapar_stream_t *m,
		const dapar_rule_t **rule, int prevmatch)
{
	dapar_queue_t *queue = m->current;
	dapar_state_t *p, *start;
	start = queue->state + m->endold;
	p = queue->state + queue->size;
	while (p > start) {
		p--;
		if (p->rule == rule && p->prevmatch == prevmatch)
			return p - queue->state;
	}
	start = queue->state;
	p = queue->state + m->startold;
	while (p > start) {
		p--;
		if (p->rule == rule && p->prevmatch == prevmatch)
			return p - queue->state;
	}
	return -1;
}

static dapar_err_t add_caller(dapar_queue_t *queue, dapar_state_t *p,
		int newcaller)
{
	if (p->firstcaller >= 0) {
		int tmp, s = p->firstcaller;
		int count = 0;
		/* First check if newcaller is in the same ring as
		   p->firstcaller already... */
		do {
			if (s == newcaller)
				return DAPAR_SUCCESS;
			s = queue->state[s].nextcaller;
			count++;
			/* Regression test for fast-forward bugs */
			assert(s >= 0 && count <= queue->size);
		} while (s != p->firstcaller);
		/* Confirmed the rings are separate so now join them... */
		tmp = queue->state[p->firstcaller].nextcaller;
		queue->state[p->firstcaller].nextcaller =
			queue->state[newcaller].nextcaller;
		queue->state[newcaller].nextcaller = tmp;
	} else {
		p->firstcaller = newcaller;
	}
	return DAPAR_SUCCESS;
}

static dapar_err_t enqueue(dapar_stream_t *m, dapar_queue_t *queue,
		const dapar_state_t *enq)
{
	/*
	 * Note that enqueue() does not check for duplicates first so the
	 * caller must ensure that enq is unique {rule, prevmatch}.
	 */
	dapar_state_t *insert;
	if (queue->size >= queue->max) {
		dapar_err_t err = grow_queues(m);
		if (err)
			return err;
	}
	insert = queue->state + queue->size;
	*insert = *enq;
	insert->matchedempty = 0;
	if (insert->prevmatch >= 0)
		m->match[insert->prevmatch].refcount++;
	DPRINTF(("\t-> %s+%d %s[%d]\n",
		enq->rulehead->name,
		(int)(enq->rule - enq->rulehead->def),
		(queue == m->current) ? "" : "next",
		queue->size));
	queue->size++;
	return DAPAR_SUCCESS;
}

static dapar_err_t requeue(dapar_stream_t *m, int i, dapar_queue_t *dest,
		int ruledelta)
{
	dapar_state_t enq = m->current->state[i];
	enq.rule += ruledelta;
	if (dest == m->current &&
	    find_in_current(m, enq.rule, enq.prevmatch) >= 0)
		return DAPAR_SUCCESS;
	/* else dest == m->next.
	 * We don't waste time checking for duplicates in the next queue
	 * because in theory, the uniqueness of each state in m->next is
	 * guaranteed by the uniqueness of the state in m->current that
	 * preceded it.
	 */
	return enqueue(m, dest, &enq);
}

static dapar_err_t expand_rule(dapar_stream_t *m, const dapar_rule_t *rule,
		int prevmatch, int caller)
{
	const dapar_rule_t **def = rule->def;
	dapar_queue_t *current = m->current;
	dapar_err_t err = DAPAR_SUCCESS;
	dapar_state_t enq;
#if FASTFORWARD_ENABLED
	/* because fast-forwarding involves memcmp of dapar_state_t, including
	   unused padding bytes */
	memset(&enq, 0, sizeof(enq));
#endif
	enq.prevmatch = prevmatch;
	enq.origin = m->pos;
	enq.firstcaller = caller;
	enq.nextcaller = -1;
	/*
	 * textorigin goes one past the next future character in the
	 * textbuf.  This is because we're potentially at the start of
	 * a token, and therefore need to leave room to terminate the
	 * previous token with a nul first.
	 */
	enq.textorigin = m->textused + 1;
	enq.subrule = 0;
	enq.reloc = -1;
	enq.rulehead = rule;
	enq.matchedempty = 0;
	enq.depth = caller >= 0 ? current->state[caller].depth + 1 : 0;
	enq.exceptid = 0;
	enq.exceptoffset = -1;
	do {
		enq.rule = def;
		err = enqueue(m, current, &enq);
		enq.exceptid = 0;
		while (*def != DAPAR_OR)
			def++;
		if (def[-1] != DAPAR_OR) {
			const char *prev = (const char*)def[-1];
			if (prev[0] == '\0' && prev[1] == _DAPAR_EXCEPT[1]) {
				int eid = m->nextexceptid++;
				enq.exceptid = -eid;
				current->state[current->size - 1].exceptid =
					eid;
			}
		}
		def++;
	} while (*def != DAPAR_OR && !err);
	return err;
}

static dapar_err_t on_state_rule(dapar_stream_t *m, dapar_state_t *state,
		int s)
{
	const dapar_rule_t *rulehead = *state->rule;
	dapar_queue_t *current = m->current;
	dapar_err_t err = DAPAR_SUCCESS;
	int existing;
	if (state->rule != NULL) {
		DPRINTF(("\t=> %s\n", rulehead->name));
	}
	state->nextcaller = s; /* Always a circular list */
	existing = find_in_current(m, rulehead->def, state->prevmatch);
	if (existing < 0) {
		err = expand_rule(m, rulehead, state->prevmatch, s);
	} else {
		dapar_state_t *found = current->state + existing;
		err = add_caller(current, found, s);
		if (!err && found->matchedempty) {
			dapar_state_t req = current->state[s];
			req.nextcaller = -2;
			req.rule++;
			err = enqueue(m, current, &req);
		}
	}
	return err;
}

dapar_err_t dapar_stream_reset(dapar_stream_t *m)
{
	m->nmatches = 0;
	m->firstfreematch = -1;
	m->lastgrammarmatch = -1;
	m->couldgrammarmatch = 0;
	m->textused = 0;
	m->pos.offset = 0;
	m->pos.line = 1;
	m->pos.column = 0;
	m->error.err = DAPAR_SUCCESS;
	m->error.pos.line = 0;
	m->startold = 0;
	m->endold = 0; 
	m->queue[0].size = 0;
	m->queue[1].size = 0;
	m->current = m->queue;
	m->next = m->queue + 1;
	m->lastsure = -1;
	m->intoken = 0;
	m->utf8buflen = 0;
	m->nextexceptid = 1;
	return expand_rule(m, m->grammar, -1, -1);
}

dapar_err_t dapar_stream_init(dapar_stream_t *m, const dapar_rule_t *grammar)
{
	m->queue[0].max = 0;
	m->queue[0].state = NULL;
	m->queue[1].state = m->queue[0].state + m->queue[0].max;
	m->queue[1].max = m->queue[0].max;
	m->maxmatches = 0;
	m->match = NULL;
	m->grammar = grammar;
	m->textbuf = NULL;
	m->textmax = 0;
	m->setting[DAPAR_AMBIGUITYTOLERANCE] =DAPAR_AMBIGUITYTOLERANCE_DEFAULT;
	m->setting[DAPAR_KEEPANON] = DAPAR_KEEPANON_DEFAULT;
	m->setting[DAPAR_DISAMBIGUATE] = DAPAR_DISAMBIGUATE_DEFAULT;
	m->setting[DAPAR_MAXSTATES] = DAPAR_MAXSTATES_DEFAULT;
	return dapar_stream_reset(m);
}

void dapar_stream_configure(dapar_stream_t *m, dapar_setting_t name, int value)
{
	m->setting[name] = value;
}

int dapar_stream_configured(dapar_stream_t *m, dapar_setting_t name)
{
	return m->setting[name];
}

static dapar_err_t reserve_text(dapar_stream_t *m, int size)
{
	dapar_err_t err = DAPAR_SUCCESS;
	if (m->textused >= m->textmax - size) {
		char *newtextbuf;
#ifdef DEBUGHEAP
		int newmax = m->textmax + size;
#else
		int newmax = m->textmax * 2;
		if (!newmax)
			newmax = INIT_TEXTMAX;
		while (newmax < m->textmax + size)
			newmax *= 2;
#endif
		newtextbuf = (char*)realloc(m->textbuf, newmax);
		if (newtextbuf == NULL) {
			err = DAPAR_ERR_MEM;
		} else {
			m->textbuf = newtextbuf;
			m->textmax = newmax;
		}
	}
	return err;
}

static dapar_err_t save_char(dapar_stream_t *m, int preterm, dapar_unicode_t c)
{
	int clen = UTF8_ENCODE_LEN(c);
	dapar_err_t err = reserve_text(m, (preterm ? 1 : 0) + clen + 1);
	if (!err) {
		int elen;
		char *dest = m->textbuf + m->textused;
		if (preterm) {
			dest++;
			m->textused++;
		}
		elen = encode_utf8(c, dest);
		if (elen == 0) {
			err = DAPAR_ERR_MULTIBYTE;
		} else {
			dest[elen] = '\0';
			m->textused += elen;
		}
	}
	return err;
}

static dapar_unicode_t read_set_char(const char **p)
/*
 * Parse a set character, which is any ASCII character except '#'.
 * Characters beginning with # are unicode values like #xB00F #0308
 */
{
	const char *c = *p;
	dapar_unicode_t u = 0;
	if (c[0] == '#' && c[1]) {
		dapar_unicode_t radix = 0;
		if (c[1] == c[0]) {
			u = c[1];
			*p += 2;
		} else if (c[1] == 'x') {
			radix = 16;
			c += 2;
		} else if (c[1] == '0') {
			radix = 8;
			c += 2;
		} else if (c[1] >= '1' && c[1] <= '9') {
			radix = 10;
		}
		if (radix) {
			while (*c) {
				dapar_unicode_t d = *c;
				dapar_unicode_t digit;
				if (d >= '0' && d <= '9')
					digit = d - '0';
				else if (d >= 'a' && d <= 'z')
					digit = d - 'a' + 10;
				else if (d >= 'A' && d <= 'Z')
					digit = d - 'A' + 10;
				else
					break;
				c++;
				u = (u * radix) + digit;
			}
			*p = c;
		} else {
			u = c[0];
			*p += 1;
		}
	} else {
		u = c[0];
		*p += 1;
	}
	return u;
}

/* A devious way to avoid calling read_set_char(), most of the time */
#define READ_SET_CHAR(p) ( (**(p) != '#') ? *((*(p))++) : read_set_char(p) )

static dapar_bool_t char_in_set(dapar_unicode_t c, const char *set)
{
	const char *s = set;
	dapar_bool_t inverted = 0;
	if (s[0] == '^') {
		inverted = 1;
		s++;
	}
	while (*s) {
		dapar_unicode_t min = READ_SET_CHAR(&s);
		if (s[0] == '-' && s[1]) {
			dapar_unicode_t max;
			s++;
			max = READ_SET_CHAR(&s);
			if (c >= min && c <= max)
				return !inverted;
		} else if (c == min) {
			return !inverted;
		}
	}
	return inverted;
}

static int dapar_atoi(const char *a)
{
	int i = 0;
	const char *p = a;
	while (*p) {
		i = i * 10 + *p - '0';
		p++;
	}
	return i;
}

static dapar_err_t save_match(dapar_stream_t *m, const dapar_state_t *state,
		int *id)
{
	int i, len, previd;
	dapar_match_t *match;
	const dapar_rule_t *rule = state->rulehead;
	len = m->pos.offset - state->origin.offset;
	previd = state->prevmatch;
	if (rule->type == DAPAR_RULE_ANONYMOUS &&
	    !m->setting[DAPAR_KEEPANON] &&
	    rule != m->grammar) {
		*id = previd;
		DPRINTF(("\tMATCHANON %s at %d len %d  pm=%d\n",
			rule->name, state->origin.offset, len, previd));
		return DAPAR_SUCCESS;
	}
	/* first try recycling some old memory */
	i = m->firstfreematch;
	if (i >= 0) {
		m->firstfreematch = m->match[i].nextsame;
	} else {
		/* last resort: allocate more memory */
		i = m->nmatches;
		if (i >= m->maxmatches) {
			dapar_match_t *newmatch;
			int newmaxmatches = m->maxmatches <= 0 ?
				INIT_MAXMATCHES :
#ifdef DEBUGHEAP
				m->maxmatches + 1;
#else
				m->maxmatches * 2;
#endif
			newmatch = (dapar_match_t*)realloc(m->match,
				sizeof(dapar_match_t) * newmaxmatches);
			if (newmatch == NULL)
				return DAPAR_ERR_MEM;
			m->match = newmatch;
			m->maxmatches = newmaxmatches;
		}
		m->nmatches = i + 1;
	}
	DPRINTF(("\tMATCH[%d]  %s at %d len %d  pm=%d\n",
		i, rule->name, state->origin.offset, len, previd));
	match = m->match + i;
	match->origin = state->origin;
	match->length = len;
	match->textsize = m->textused - state->textorigin;
	match->rule = rule;
	match->parent = NULL;
	match->firstchild = NULL;
	match->lastchild = NULL;
	match->nextsibling = NULL;
	match->prevsibling = NULL;
	match->user = NULL;
	match->text = (char*)NULL + state->textorigin;
	match->used = 0;
	match->refcount = 0;
	match->prevmatch = previd;
	match->nextsame = -1;
	match->depth = state->depth;
	if (previd >= 0)
		m->match[previd].refcount++;
	*id = i;
	return DAPAR_SUCCESS;
}

static dapar_err_t on_state_excepted(dapar_stream_t *m, int s)
{
	dapar_err_t err = DAPAR_SUCCESS;
        dapar_queue_t *current = m->current;
	dapar_state_t *state = current->state + s;
	int eid = state->exceptid;
	if (eid < 0) {
		dapar_state_t *f, *fmax = current->state + current->size;
		eid = -eid;
		for (f = current->state + s + 1; f < fmax; f++)
			if (f->exceptid == eid)
				f->exceptoffset = m->pos.offset;
		DPRINTF(("    POSSIBLE EXCEPT (if len == %d)\n", len));
	}
	return err;
}

static dapar_err_t on_state_complete(dapar_stream_t *m, dapar_state_t *state,
		int s, dapar_unicode_t c)
{
	int matchid = -1;
	dapar_err_t err;

	if (state->exceptid < 0)
		return on_state_excepted(m, s);

	if (state->rulehead == m->grammar) {
		m->couldgrammarmatch = 1;
		if (c != NOMOREINPUT)
			return DAPAR_SUCCESS;
	}
	err = save_match(m, state, &matchid);
	if (state->rulehead == m->grammar && matchid >= 0) {
		m->match[matchid].nextsame = m->lastgrammarmatch;
		m->lastgrammarmatch = matchid;
	}
	/* Now find and increment all current states that called 'state' */
	if (!err) {
		dapar_queue_t *queue = m->current;
		int firstcaller = state->firstcaller;
		if (firstcaller >= 0) {
			int k = firstcaller;
			do {
				dapar_state_t *caller = queue->state + k;
				dapar_state_t enq = *caller;
				k = caller->nextcaller;
				assert(k < queue->size && k >= 0);
				enq.prevmatch = matchid;
				enq.rule++;
				enq.nextcaller = -3;
				err = enqueue(m, queue, &enq);
			} while (k != firstcaller && !err);
			state = queue->state + s;
		}
		if (m->pos.offset == state->origin.offset) {
			/* It is a zero-length match */
			if (state->rulehead->def == state->rule) {
				state->matchedempty = 1;
			} else {
				int headid = find_in_current(m,
						state->rulehead->def,
						state->prevmatch);
				if (headid >= 0)
					queue->state[headid].matchedempty = 1;
			}
		}
	}
	return err;
}

static dapar_err_t on_state_except(dapar_stream_t *m, int s)
{
	dapar_err_t err = DAPAR_SUCCESS;
        dapar_queue_t *current = m->current;
	dapar_state_t *state = current->state + s;
	int eid = state->exceptid;
	if (eid > 0) {
		int f;
		dapar_bool_t pending = 0;
		DPRINTF(("    EXCEPT-ABLE match\n"));
		eid = -eid;
		for (f = s + 1; f < current->size; f++) {
			if (current->state[f].exceptid == eid) {
				/* This match might yet be excepted.
				   Just requeue it and try again later */
				dapar_state_t enq = *state;
				pending = 1;
				err = enqueue(m, current, &enq);
				if (err)
					break;
			}
		}
		/* No pending exception found? Increment the rule,
		   should make it on_state_complete next time */
		if (!pending)
			err = requeue(m, s, current, 1);
	}
	return err;
}

static dapar_err_t on_state_string(dapar_stream_t *m, int s, dapar_unicode_t c)
{
	dapar_state_t *state = m->current->state + s;
	const char *expect = (const char*)*state->rule + state->subrule;
	dapar_err_t err = DAPAR_SUCCESS;
	if (c == (dapar_unicode_t)*expect) {
		dapar_state_t enq = *state;
		if (expect[1] == '\0') {
			enq.rule++;
			enq.subrule = 0;
		} else {
			enq.subrule++;
		}
		err = enqueue(m, m->next, &enq);
	}
	return err;
}

static dapar_err_t on_state_optional(dapar_stream_t *m, const char *arg, int s)
{
	dapar_queue_t *current = m->current;
	dapar_err_t err = requeue(m, s, current, dapar_atoi(arg)+1);
	if (!err)
		err = requeue(m, s, current, 1);
	return err;
}

static dapar_err_t on_state_repeat(dapar_stream_t *m, int s, const char *arg)
{
	dapar_queue_t *current = m->current;
	dapar_err_t err = requeue(m, s, current, -dapar_atoi(arg));
	if (!err)
		err = requeue(m, s, current, 1);
	return err;
}

static dapar_err_t on_state_anychar(dapar_stream_t *m, dapar_unicode_t c,
		int s)
{
	dapar_err_t err = (c == NOMOREINPUT) ? DAPAR_SUCCESS :
		requeue(m, s, m->next, 1);
	return err;
}

static dapar_err_t on_state_space(dapar_stream_t *m, dapar_unicode_t c, int s)
{
	/* Optimized rule to match zero or more whitespace characters... */
	dapar_err_t err = requeue(m, s, m->current, 1);
	if ((c == ' ' || c == '\t' || c == '\r' || c == '\n') && !err)
		err = requeue(m, s, m->next, 0);
	return err;
}

static dapar_err_t on_state_charset(dapar_stream_t *m, dapar_state_t *state,
		dapar_unicode_t c, int s)
{
	dapar_err_t err = DAPAR_SUCCESS;
	const char *set = (const char*)*state->rule + 2;
	if (c != NOMOREINPUT && char_in_set(c, set))
		err = requeue(m, s, m->next, 1);
	return err;
}

static void locate_ambiguity(dapar_stream_t *m)
{
	int firstfork = -1, r, maxused = 1, firstroot = m->lastgrammarmatch;
	dapar_pos_t pos;
	if (firstroot < 0) {
		/*
		 * Sometimes with heuristic early ambiguity detection there
		 * might not be any actual grammar matches yet. So use the
		 * tails of the current critical paths as root matches.
		 */
		int s;
		for (s = 0; s < m->startold; s++) {
			int n = m->current->state[s].prevmatch;
			m->match[n].nextsame = firstroot;
			firstroot = n;
		}
	}
	for (r = firstroot; r >= 0; r = m->match[r].nextsame) {
		int i;
		for (i = r; i >= 0; i = m->match[i].prevmatch) {
			if (++m->match[i].used > maxused) {
				maxused = m->match[i].used;
				firstfork = i;
			}
		}
	}
	pos = m->pos;
	pos.offset++;
	DPRINTF(("Ambiguity after MATCH[%d].\n", firstfork));
	for (r = firstroot; r >= 0; r = m->match[r].nextsame) {
		int i;
		DPRINTF(("ROOT MATCH %d\n", r));
		for (i = r; i >= 0; i = m->match[i].prevmatch) {
			dapar_match_t *match = m->match + i;
			DPRINTF(("\tcaller MATCH[%d], rc=%d, used=%d, "
				"%s at %d len %d\n",
				i, match->refcount, match->used,
				match->rule->name, match->origin.offset,
				match->length));
			if (match->prevmatch == firstfork) {
				DPRINTF(("\tAMBIGUOUS MATCH[%d]\n", i));
				if (pos.offset > match->origin.offset)
					pos = match->origin;
				break;
			}
		}
	}
	m->error.pos = pos;
}

static void free_unreachable_matches(dapar_stream_t *m,
		dapar_state_t *dead, int ndead)
{
	/* Update refcounts to find match slots that are no longer
	 * reachable so can be reused... */
	int s;
	for (s = 0; s < ndead; s++) {
		int i = dead[s].prevmatch;
		while (i >= 0 && --(m->match[i].refcount) <= 0) {
			m->match[i].nextsame = m->firstfreematch;
			m->firstfreematch = i;
			i = m->match[i].prevmatch;
		}
	}
}

dapar_err_t dapar_stream_input_char(dapar_stream_t *m, dapar_unicode_t c)
{
	int s, intoken, newtoken, unrefstart;
	int flip = m->pos.offset & 1;
	dapar_queue_t *current = m->current = &m->queue[flip];
	dapar_queue_t *next = m->next = &m->queue[flip ^ 1];
	dapar_err_t err = m->error.err;
	int tolerance = m->setting[DAPAR_AMBIGUITYTOLERANCE];

	if (err) {
		goto return_err;
	} else if (current->size == 0) {
		err = DAPAR_ERR_CHAR; /* out of states, must be a bad char */
		goto return_err;
	} else if (!m->setting[DAPAR_DISAMBIGUATE] &&
	           tolerance &&
	           m->pos.offset - m->lastsure > tolerance) {
		/*
		 * Heuristic detection of ambiguous grammars, which sometimes
		 * can take forever to match. So we need to detect them
		 * early.
		 */
		err = DAPAR_ERR_AMBIGUOUS;
		locate_ambiguity(m);
		goto return_err;
	}

	if (c == '\n') {
		m->pos.line++;
		m->pos.column = 0;
	} else {
		m->pos.column++;
	}
	DPRINTF(("----- Character '%c' at line %d col %d\n",
		c == NOMOREINPUT ? '$' : c, m->pos.line, m->pos.column));
	next->size = 0;
	m->couldgrammarmatch = 0;
	for (s=0; s < current->size; s++) {
		dapar_state_t *state = current->state + s;
		const char *rule;
#ifdef DEBUGPRINT
		DPRINTF(("[%d] State %s+%d @%d,  fc=%d, nc=%d, pm=%d\n",
			s,
			state->rulehead->name,
			(int)(state->rule - state->rulehead->def),
			state->origin.offset,
			state->firstcaller, state->nextcaller,
			state->prevmatch));
		if (s >= m->startold && s < m->endold) {
			DPRINTF(("\tskipped because it's just an old caller\n"
				));
			continue;
		}
#else
		if (s == m->startold) {
			s = m->endold;
			if (s >= current->size)
				break;
			state = current->state + s;
		}
#endif
		if (state->exceptoffset == m->pos.offset)
			continue;
		rule = (const char *)(*state->rule);
		/*
		 * This might be ugly but we want the functions
		 * inlined.  Also, the cases are ordered according to
		 * likelihood so this statement tends to perform better
		 * than a switch()...
		 */
		err =   (rule == DAPAR_OR) ?
				on_state_complete(m, state, s, c) :
			(rule[0] != '\0') ?
				on_state_string(m, s, c) :
			(rule[1] == _DAPAR_RULE_HEAD[1]) ?
				on_state_rule(m, state, s) :
			(rule[1] == DAPAR_OPTIONAL_NEXT(0)[1]) ?
				on_state_optional(m, rule+2, s) :
			(rule[1] == DAPAR_REPEAT_PREV(0)[1]) ?
				on_state_repeat(m, s, rule+2) :
			(rule[1] == DAPAR_SPACE[1]) ?
				on_state_space(m, c, s) :
			(rule[1] == DAPAR_CHAR("")[1]) ?
				on_state_charset(m, state, c, s) :
			(rule[1] == DAPAR_ANYCHAR[1]) ?
				on_state_anychar(m, c, s) :
			(rule[1] == _DAPAR_EXCEPT[1]) ?
				on_state_except(m, s) :
			DAPAR_ERR_BADRULE;
		if (err)
			goto return_err;
	}
	if (next->size == 1)
		m->lastsure = m->pos.offset;
	newtoken = 0;
	unrefstart = -1;
	intoken = m->intoken;
#if FASTFORWARD_ENABLED
	if (m->startold == next->size &&
	    !memcmp(next->state, current->state,
	            next->size * sizeof(dapar_state_t))) {
		int i, canff = 1;
		for (i = m->startold; i < m->endold; i++) {
			if (current->state[i].nextcaller >= m->endold) {
				canff = 0;
				break;
			}
		}
		if (canff) {
			DPRINTF(("FASTFORWARD\n"));
			memcpy(next->state + m->startold,
				current->state + m->startold,
				(m->endold - m->startold) *
					sizeof(dapar_state_t)
				);
			next->size = m->endold;
			unrefstart = m->endold;
		}
	}
#endif
	if (unrefstart < 0)
	{
		/* Find and re-enqueue any continuing possible callers */
		intoken = 0;
		m->startold = next->size;
		for (s=0; s < next->size; s++) {
			dapar_state_t *callee = next->state + s;
			if (callee->rulehead->type == DAPAR_RULE_TOKEN) {
				intoken++;
				if (callee->textorigin > m->textused)
					newtoken++;
			}
			DPRINTF(("next[%d]: %s+%d first caller is...\n",
				s, callee->rulehead->name,
				(int)(callee->rule - callee->rulehead->def)));
			if (callee->firstcaller >= 0) {
				int oldfirst = callee->firstcaller;
				dapar_state_t *caller =
					current->state + oldfirst;
				if (caller->reloc < 0) {
					err = requeue(m, oldfirst, next, 0);
					if (err)
						goto return_err;
					caller = current->state + oldfirst;
					caller->reloc = next->size - 1;
					callee = next->state + s;
				} else {
					DPRINTF(("\texisting next[%d]\n",
						caller->reloc));
				}
				callee->firstcaller = caller->reloc;
			}
			DPRINTF(("   and is equivalent to...\n"));
			if (callee->nextcaller >= 0) {
				int oldnext = callee->nextcaller;
				dapar_state_t *caller =
					current->state + oldnext;
				if (caller->reloc < 0) {
					err = requeue(m, oldnext, next, 0);
					if (err)
						goto return_err;
					caller = current->state + oldnext;
					caller->reloc = next->size - 1;
					callee = next->state + s;
				} else {
					DPRINTF(("\texisting next[%d]\n",
						caller->reloc));
				}
				callee->nextcaller = caller->reloc;
			}
		}
		m->endold = next->size;
		unrefstart = 0;
	}
	free_unreachable_matches(m, current->state + unrefstart,
			current->size - unrefstart);
	if (intoken) {
		err = save_char(m, newtoken, c);
		if (err)
			goto return_err;
	}
	if (c == NOMOREINPUT && m->pos.offset) {
		DPRINTF(("Buffer efficiency: Copied %d/%d bytes (%d%%)\n",
			m->textused, m->pos.offset,
			m->textused * 100 / m->pos.offset));
	}
	m->intoken = intoken;
	m->pos.offset++;
return_err:
	m->error.err = err;
	return err;
}

dapar_bool_t dapar_stream_matched(const dapar_stream_t *m)
{
	return m->couldgrammarmatch;
}

dapar_err_t dapar_stream_input_utf8(dapar_stream_t *m, const char *input,
		int size)
{
	dapar_err_t err = DAPAR_SUCCESS;
	const char *p = input;
	if (size < 0) {
		while (!err && *p) {
			dapar_unicode_t c = decode_utf8(&p);
			err = (c == UNICODE_INVALID) ?
				DAPAR_ERR_MULTIBYTE :
				dapar_stream_input_char(m, c);
		}
	} else {
		const char *end = input + size;
		/* First consume incomplete characters from previous calls */
		if (m->utf8buflen) {
			int i = m->utf8buflen;
			int needlen = UTF8_DECODE_LEN(m->utf8buf);
			while (p < end && i < needlen) {
				m->utf8buf[i] = *p;
				i++;
				p++;
			}
			if (i == needlen) {
				char tmp[4];
				m->utf8buflen = 0;
				for (i = 0; i < needlen; i++)
					tmp[i] = m->utf8buf[i];
				err = dapar_stream_input_utf8(m, tmp, needlen);
			}
		}
		while (!err && p < end) {
			if ((p + UTF8_DECODE_LEN(p)) > end) {
				/* truncated multi-byte character?
				   save it for next time... */
				int i = 0;
				while (p < end) {
					m->utf8buf[i] = *p;
					p++;
					i++;
				}
				m->utf8buflen = i;
				if (i > 3)
					err = DAPAR_ERR_ARG;
				break;
			} else {
				dapar_unicode_t c = decode_utf8(&p);
				err = (c == UNICODE_INVALID) ?
					DAPAR_ERR_MULTIBYTE :
					dapar_stream_input_char(m, c);
			}
		}
	}
	return err;
}

dapar_err_t dapar_stream_input_raw(dapar_stream_t *m, const void *input,
		int size)
{ /* XXX untested */
	dapar_err_t err = DAPAR_SUCCESS;
	if (size < 0) {
		err = DAPAR_ERR_ARG;
	} else {
		const dapar_byte_t *p = (const dapar_byte_t*)input;
		const dapar_byte_t *end = p + size;
		while (!err && p < end) {
			err = dapar_stream_input_char(m, *p);
			p++;
		}
	}
	return err;
}

dapar_err_t dapar_stream_input_utf32(dapar_stream_t *m,
		const dapar_ucs4_t *input, int size)
{ /* XXX untested */
	dapar_err_t err = DAPAR_SUCCESS;
	const dapar_ucs4_t *p = input;
	if (size < 0) {
		while (!err && *p) {
			err = dapar_stream_input_char(m, *p);
			p++;
		}
	} else {
		const dapar_ucs4_t *end = p + size;
		while (!err && p < end) {
			err = dapar_stream_input_char(m, *p);
			p++;
		}
	}
	return err;
}

static int count_solutions(const dapar_stream_t *m)
{
	int r, count = 0;
	for (r = m->lastgrammarmatch; r >= 0; r = m->match[r].nextsame)
		count++;
	return count;
}

static dapar_match_t *select_root(const dapar_stream_t *m, int instance)
{
	int root = -1;
	if (instance <= 1) {
		root = m->lastgrammarmatch;
	} else {
		int r, count = 0;
		for (r = m->lastgrammarmatch; r >= 0; r=m->match[r].nextsame) {
			count++;
			if (count == instance) {
				root = r;
				break;
			}
		}
	}
	return root >= 0 ? m->match + root : NULL;
}

dapar_err_t dapar_stream_end(dapar_stream_t *m, const dapar_tree_t **tree)
{
	dapar_match_t *root, *p;
	int solutions, disambiguate;
	dapar_err_t err;

	err = dapar_stream_input_char(m, NOMOREINPUT);
	if (err)
		goto return_err;

	solutions = count_solutions(m);
	disambiguate = m->setting[DAPAR_DISAMBIGUATE];
	if (solutions > 1 && !disambiguate) {
		err = DAPAR_ERR_AMBIGUOUS;
		locate_ambiguity(m);
		goto return_err;
	} else if (solutions <= 0) {
		err = DAPAR_ERR_EOS;
		goto return_err;
	}

	root = select_root(m, disambiguate);
	if (root == NULL) {
		err = DAPAR_ERR_ARG;
		goto return_err;
	}

	p = root;
	while (p >= m->match) {
		int po, pz;
		p->used = 1;
		po = p->origin.offset;
		pz = po + p->length;
		if (p->prevmatch >= 0) {
			dapar_match_t *q = m->match + p->prevmatch;
			int qo = q->origin.offset;
			int qz = qo + q->length;
			if (qo >= po && qz <= pz && q->depth >= p->depth) {
				/* q must be the last child of p */
				q->parent = p;
				p->lastchild = q;
				p->firstchild = q;
			} else {
				/*
				 * q is either the previous sibling of
				 * p, or previous sibling of one of p's
				 * ancestors...
				 */
				dapar_match_t *g = p->parent;
				while (g != NULL &&
						(qo < g->origin.offset ||
						 (qz <= g->origin.offset &&
						  g->depth >= q->depth))) {
					g = g->parent;
				}
				q->parent = g;
				if (g != NULL) {
					dapar_match_t *s = g->firstchild;
					q->nextsibling = s;
					s->prevsibling = q;
					g->firstchild = q;
				}
			}
		}

		/* Tokens aren't meant to have children!
		   but if you really must then this fixes p->text */
		if (p->rule->type == DAPAR_RULE_TOKEN &&
		    p->firstchild != NULL) {
			int size = 0;
			int src = (int)(p->text - (char*)NULL);
			int endsrc = src + p->textsize;
			int dest = m->textused + 1;
			err = reserve_text(m, p->textsize + 2);
			if (err)
				goto return_err;
			p->text = (char*)(dest + (char*)NULL);
			while (src < endsrc) {
				if (!m->textbuf[src]) {
					src++;
					if (src >= endsrc)
						break;
				}
				m->textbuf[dest] = m->textbuf[src];
				src++;
				dest++;
				size++;
			}
			p->textsize = size;
			m->textbuf[dest] = '\0';
			m->textused = dest;
		}

		p = m->match + p->prevmatch;
	}

	p = root;
	while (p >= m->match) {
		if (p->rule->type == DAPAR_RULE_TOKEN) {
			p->text += (m->textbuf - (char*)NULL);
			p->text[p->textsize] = '\0';
		} else {
			p->text = NULL;
			p->textsize = -1;
		}
		p = m->match + p->prevmatch;
	}

	m->tree.root = root;
	m->tree.elems = m->nmatches;
	m->tree.elem = m->match;
	m->tree.textbuf = m->textbuf;
	if (m->tree.root->rule == m->grammar &&
	    (m->grammar->type == DAPAR_RULE_ANONYMOUS) &&
	    !m->setting[DAPAR_KEEPANON] &&
	    m->tree.root->nextsibling == NULL) {
		dapar_match_t *top = m->tree.root->firstchild;
		m->tree.root = top;
		top->parent = NULL;
		while (top->nextsibling != NULL) {
			top = top->nextsibling;
			top->parent = NULL;
		}
		m->tree.elems--;
	}

return_err:
	if (tree != NULL)
		*tree = err ? NULL : &m->tree;
	m->error.err = err;
	return err;
}

void dapar_stream_copytree(dapar_stream_t *m, dapar_tree_t *tree)
{
	*tree = m->tree;
	m->tree.root = NULL;
	m->tree.elem = NULL;
	m->tree.elems = 0;
	m->tree.textbuf = NULL;
	m->match = NULL;
	m->maxmatches = 0;
	m->nmatches = 0;
	m->textbuf = NULL;
	m->textused = 0;
	m->textmax = 0;
}

void dapar_stream_free(dapar_stream_t *m)
{
	if (m->queue[0].state != NULL) {
		int q;
		free(m->queue[0].state);
		for (q=0; q < 2; q++) {
			m->queue[q].state = NULL;
			m->queue[q].max = 0;
			m->queue[q].size = 0;
		}
	}
	if (m->match != NULL) {
		free(m->match);
		m->match = NULL;
	}
	m->nmatches = 0;
	if (m->textbuf != NULL) {
		free(m->textbuf);
		m->textbuf = NULL;
		m->textused = 0;
		m->textmax = 0;
	}
}

void dapar_tree_free(dapar_tree_t *t)
{
	if (t->elem != NULL) {
		free(t->elem);
		t->elem = NULL;
	}
	if (t->textbuf != NULL) {
		free((void*)t->textbuf);
		t->textbuf = NULL;
	}
	t->root = NULL;
}

const dapar_errorinfo_t *dapar_stream_errorinfo(dapar_stream_t *m)
{
	if (m->error.pos.line <= 0)
		m->error.pos = m->pos;
	return &m->error;
}

const char *dapar_err_string(dapar_err_t err)
{
	return (err < _DAPAR_ERRS) ? dapar_err_str[err] : NULL;
}

