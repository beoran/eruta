#include "a5teroids.hpp"

SmallAsteroid::SmallAsteroid() :
   Asteroid(10, RES_SMALLASTEROID)
{
   points = 10;
}

SmallAsteroid::~SmallAsteroid()
{
}

