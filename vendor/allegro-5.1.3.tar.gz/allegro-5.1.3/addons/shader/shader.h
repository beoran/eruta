#ifndef _AL_SHADER_H
#define _AL_SHADER_H

#include "allegro5/internal/aintern_shader.h"

#endif
